import { colors, fonts } from "../../constants/GlobalStyles";

const { StyleSheet, Dimensions } = require("react-native");

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.mainBackground,
  },
  sectionTop: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  logo: {
    height: 180,
    width: 150,
    bottom: 20,
  },
  sectionMiddle: {
    flex: 1,
    marginHorizontal: 20,
  },
  inputItem: {
    flexDirection: "row",
    marginBottom: 10,
    borderWidth: 0.5,
    borderColor: "gray",
    borderRadius: 10,
    height: 50,
    justifyContent: "space-between",
    alignItems: "center",
  },
  userIcon: {
    right: 10,
  },
  title: {
    fontSize: 30,
    fontWeight: "600",
    color: colors.darkOrange,
  },
  inputTitle: {
    color: "#2A3256",
    fontSize: 16,
    fontFamily: "Lexend-Medium",
    marginBottom: 5,
  },
  button: {
    backgroundColor: colors.mainButton,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 10,
  },
  loginContainer: {
    // marginHorizontal: 20,
  },
  login: {
    fontSize: 16,
    fontWeight: "500",
    lineHeight: 20,
    color: "#FFFFFF",
  },
  registerContainer: {
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginBottom: 10,
  },
  register: {
    fontSize: 16,
    color: colors.darkOrange,
    fontFamily: "lexend-medium",
    fontWeight: "700",
  },
  error: {
    fontSize: 14,
    fontFamily: fonts.headerFont,
    color: "red",
  },
  registerforget: {
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginBottom: 30,
  }
});
export default styles;
