export const colors = {
  mainBackground: "#FFF",
  mainHeader: "#b41a88",
  // mainButton: "#b41a88",
  mainButton: "#b41a88",
  white: "#FFF",
  dark: "#000",
  primary: "#b41a88",
  secondary: "#b41a88",
  light: "#E5E5E5",
  grey: "#908e8c",
  darkOrange: "#693811",
  lightgrey: "#D3D3D3",
  green: "#009D7C",
};

export const fonts = {
  baseFont: "Lexend-Regular",
  headerFont: "Lexend-Medium",
};
