import React from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { colors } from "../constants/GlobalStyles";
import Icon from "react-native-vector-icons/MaterialIcons";

const QuantitySelector = ({ quantity, setQuantity, incNum }) => {
  const onMinus = () => {
    setQuantity(Math.max(0, quantity - 1));
  };

  const onPlus = () => {
    setQuantity(quantity + 1);
    // incNum();
  };

  return (
    <View style={styles.root}>
      <Pressable onPress={onMinus} style={styles.button}>
        <Icon name="remove" size={25} color={colors.white} />
      </Pressable>

      <Text style={styles.quantity}>{quantity}</Text>

      <Pressable onPress={onPlus} style={styles.button}>
        <Icon name="add" size={25} color={colors.white} />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1,
    borderColor: "#e3e3e3",
    width: 150,
  },
  button: {
    width: 50,
    height: 35,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.primary,
  },
  butonText: {
    fontSize: 18,
    color: colors.white,
  },
  quantity: {
    color: colors.dark,
  },
});

export default QuantitySelector;
