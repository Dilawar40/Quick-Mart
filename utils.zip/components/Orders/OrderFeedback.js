import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from "react-native";
import Toast from "react-native-toast-message";
import { colors } from "../../constants/GlobalStyles";
import { APIKit } from "../../utils/APIKIT";
import Header from "../Header";

const OrderFeedback = ({ route, navigation }) => {
  const { data } = route.params;
  console.log(data[0].order_id);

  const [userTitle, setUserTitle] = useState("");
  const [userDescription, setUserDescription] = useState("");

  const TostMessage = (item) => {
    Toast.show({
      type: "success",
      text1: "Success",
      text2: item,
      topOffset: 80,
    });
  };
  const ErrorMessage = (item) => {
    Toast.show({
      type: "error",
      text1: "Error",
      text2: item,
      topOffset: 80,
    });
  };

  const handleSubmitButton = async () => {
    let id = await AsyncStorage.getItem("id");

    var dataToSend = {
      user_id: id,
      title: userTitle,
      order_id: data[0].order_id,
      description: userDescription,
    };
    console.log("dataToSend", dataToSend);
    var url = "v1/add-order-feedback";
    let response = await APIKit.post(url, dataToSend);
    if (response.data.code === 200) {
      console.log("orderFeedback", response.data);
      TostMessage(response.data.message);
      navigation.navigate("BottomTabScreen");
    } else {
      ErrorMessage(response.data.message);
      console.log("orderFeedbackError", response.data.message);
    }
  };

  return (
    <View style={styles.container}>
      <Header
        title={"Order Feedback"}
        isNavigationRequired={true}
        color={"white"}
        backgroundColor={colors.mainHeader}
        height={50}
        right={10}
      />
      <View style={styles.sectionMiddle}>
        <View style={styles.inputItem}>
          <Text style={styles.inputTitle}>Title</Text>
          <TextInput
            style={styles.inputTitlebox}
            placeholder="Type title..."
            value={userTitle}
            onChangeText={setUserTitle}
          />

          <Text style={styles.inputTitle2}>Description</Text>
          <TextInput
            style={styles.inputAddress}
            placeholder="Type description..."
            value={userDescription}
            multiline={true}
            onChangeText={setUserDescription}
          />
        </View>
        <View style={styles.inputItem}>
          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.button}
            onPress={() => handleSubmitButton()}
          >
            <Text style={styles.save}>Save</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default OrderFeedback;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.mainBackground,
  },
  sectionMiddle: {
    flex: 1,
    marginTop: 15,
    marginHorizontal: 20,
  },
  inputItem: {
    marginBottom: 20,
  },
  inputTitle: {
    color: colors.darkOrange,
    fontSize: 16,
    fontFamily: "Lexend-Medium",
    marginBottom: 5,
  },
  inputTitle2: {
    color: colors.darkOrange,
    fontSize: 16,
    fontFamily: "Lexend-Medium",
    marginBottom: 5,
    marginTop: 10,
  },
  inputTitlebox: {
    borderWidth: 0.5,
    borderColor: "gray",
    borderRadius: 10,
    height: 50,
    paddingLeft: 5,
    backgroundColor: "#fff",
    elevation: 10,
  },
  inputAddress: {
    borderWidth: 0.5,
    borderColor: "gray",
    borderRadius: 10,
    height: 100,
    paddingLeft: 5,
    backgroundColor: "#fff",
    elevation: 10,
  },
  button: {
    backgroundColor: colors.mainButton,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
    marginTop: 10,
    elevation: 10,
  },
  save: {
    fontSize: 16,
    fontWeight: "500",
    lineHeight: 20,
    color: "#FFFFFF",
  },
});
