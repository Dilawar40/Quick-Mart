import moment from "moment";
import React, { useEffect, useState } from "react";
import {
  Dimensions,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { colors, fonts } from "../../constants/GlobalStyles";
import { apiGetHistory } from "../../utils/APIKIT";

const SCREEN_WIDTH = Dimensions.get("screen").width;

const HistoryItems = () => {


  const [historyData, setHistoryData] = useState([]);

  useEffect(() => {
    setTimeout(() => {
      FetchHistory();
    }, 100);
  }, []);
  const FetchHistory = async () => {
    let response = await apiGetHistory()
      .then(function (response) {
        // console.log(response);
        if (response) {
          console.log("responseHistory", response.data);
          setHistoryData(response.data.result);
        } else {
          console.log("responseHistoryError", response.data.message);
        }
      })
      .catch(function (error) {
        // handle error
        if (error.response.status === 401) {
          console.log("Token Expire goto login screen");
          navigation.navigate("LoginScreen");
        } else {
          console.log("Other error show it to user");
        }
      });
  };
  // const navigation = useNavigation();
  const ItemView = ({ item, onPress }) => {
    return (
      <View style={styles.innerContainer}>
        <TouchableOpacity
          activeOpacity={0.8}
          style={styles.mainContainer2}
          onPress={onPress}
        >
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <Image
              style={styles.image}
              source={{
                uri: item.order_details[0].product.product_image[0].image,

              }}

              resizeMode="center"
            />

            <View style={styles.nameText}>
              <Text style={styles.customerName}>{item.order_no}</Text>
              <View style={styles.middleline}>
                <View
                  style={{
                    flexDirection: "row",
                  }}
                >
                  <Text style={styles.customerNamemoney}>order status: </Text>
                  <Text
                    style={{
                      fontSize: 12,
                      fontWeight: "600",
                      color: item.status === "canceled" ? "red" : colors.grey,
                      marginTop: 5,
                      textTransform: "capitalize",
                      fontWeight: "bold",
                    }}
                  >
                    {item.status}
                  </Text>
                </View>
                <View>
                  <Text style={styles.price}>
                    {"\u00A3"}
                    {item.total_amount}
                  </Text>
                </View>
              </View>
              <Text style={styles.date}>
                {moment(item.created_at).format("DD-MM-YYYY")}
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const renderItem = ({ item }) => {
    return (
      <ItemView
        item={item}
        onPress={() => {
          navigation.navigate("TrackOrder", {
            data: item,
          });
        }}
      />
    );
  };
  return (
    <View style={styles.container}>
      <View style={styles.mainContainer}>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={historyData}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
        />
        {historyData === undefined ? (
          <View style={styles.NoDataContainer}>
            <Image
              source={require("../../Assets/history2.jpg")}
              resizeMode="center"
              style={{ height: "100%", width: "100%" }}
            />
            <Text style={styles.NoDataText}>You have no order history.</Text>
          </View>
        ) : null}
      </View>
    </View>
  );
};

export default HistoryItems;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.mainBackground,
  },
  innerContainer: {
    marginTop: 10,
    // flex: 1,
  },
  mainContainer: {
    flex: 1,
  },
  mainContainer2: {
    height: 80,
    // width: "100%",
    borderWidth: 1,
    backgroundColor: colors.white,
    borderRadius: 20,
    marginBottom: 2,
    marginHorizontal: 10,
    borderColor: "#f4f5f4",
    elevation: 10,
  },
  image: {
    height: 60,
    width: 60,
    marginTop: 9,
    marginHorizontal: 10,
    borderRadius: 5,
  },
  nameText: {
    // flex: 1,
    marginTop: 5,
    marginHorizontal: 10,
    width: SCREEN_WIDTH - 120,
  },
  customerName: {
    fontSize: 16,
    fontWeight: "600",
    color: colors.darkOrange,
  },
  middleline: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  customerNamemoney: {
    fontSize: 12,
    fontWeight: "600",
    color: colors.grey,
    marginTop: 5,
    textTransform: "capitalize",
    fontWeight: "bold",
  },
  date: {
    color: colors.darkOrange,
    fontSize: 12,
    marginTop: 5,
  },
  price: {
    color: colors.darkOrange,
    fontWeight: "700",
  },
  NoDataContainer: {
    justifyContent: "space-around",
    alignItems: "center",
    marginTop: 50,
    marginHorizontal: 20,
  },
  NoDataText: {
    fontSize: 18,
    marginBottom: 200,
    color: colors.primary,
    fontFamily: fonts.headerFont,
  },
});
