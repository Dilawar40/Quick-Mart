import { useNavigation } from "@react-navigation/native";
import moment from "moment";
import React from "react";
import {
    Dimensions,
    FlatList,
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from "react-native";
import { colors, fonts } from "../../constants/GlobalStyles";

const SCREEN_WIDTH = Dimensions.get("screen").width;

const OngoingItems = ({ orderData }) => {
  // console.log("orderData", orderData);
  const navigation = useNavigation();

  const ItemView = ({ item, onPress }) => {
    return (
      <View style={styles.innerContainer}>
        <TouchableOpacity
          activeOpacity={0.8}
          style={styles.mainContainer2}
          onPress={onPress}
        >
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <Image
              style={styles.image}
              source={{
                uri: item.order_details[0].product.product_image[0].image,
              }}
             
              resizeMode="contain"
            />
            <View style={styles.nameText}>
              <View style={styles.header}>
                <Text style={styles.customerName}>{item.order_no}</Text>

                <Text style={styles.customerOtp}>otp: {item.order_otp}</Text>
              </View>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Text style={styles.customerNamemoney}>
                  order status:{" "}
                  {item.status === "canceled" ? colors.red : item.status}
                </Text>
                <Text style={styles.price}>
                  {"\u00A3"}
                  {item.total_amount}
                </Text>
              </View>
              <Text style={styles.date}>
                {moment(item.created_at).format("DD-MM-YYYY")}
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const renderItem = ({ item }) => {
    return (
      <ItemView
        item={item}
        onPress={() => {
          navigation.navigate("TrackOrder", {
            data: item,
          });
        }}
      />
    );
  };
  return (
    <View style={styles.container}>
      <View style={styles.mainContainer}>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={orderData}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
        />
        {orderData === undefined ? (
          <View style={styles.NoDataContainer}>
            <Image
              source={require("../../Assets/currentorder.jpg")}
              resizeMode="center"
              style={{ height: "100%", width: "100%" }}
            />
            <Text style={styles.NoDataText}>You have no ongoing order.</Text>
          </View>
        ) : null}
      </View>
    </View>
  );
};

export default OngoingItems;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.mainBackground,
  },
  innerContainer: {
    // marginTop: 10,
    marginBottom: 10,
  },
  mainContainer: {
    flex: 1,
  },
  mainContainer2: {
    height: 80,
    // width: "100%",
    borderWidth: 1,
    backgroundColor: colors.white,
    borderRadius: 20,
    marginHorizontal: 10,
    borderColor: "#f4f5f4",
    elevation: 10,
  },
  image: {
    height: 60,
    width: 60,
    marginTop: 9,
    marginHorizontal: 10,
    borderRadius: 5,
  },
  nameText: {
    // flex: 1,
    marginTop: 5,
    marginHorizontal: 10,
    width: SCREEN_WIDTH - 140,
  },
  customerName: {
    fontSize: 16,
    fontWeight: "600",
    color: colors.darkOrange,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  customerOtp: {
    fontSize: 12,
    fontWeight: "600",
    color: colors.grey,
    marginTop: 2,
    textTransform: "uppercase",
    fontWeight: "bold",
  },
  customerNamemoney: {
    fontSize: 12,
    fontWeight: "600",
    color: colors.grey,
    marginTop: 5,
    textTransform: "capitalize",
    fontWeight: "bold",
  },
  date: {
    color: colors.darkOrange,
    fontSize: 12,
    marginTop: 5,
  },
  price: {
    color: colors.darkOrange,
    fontWeight: "700",
  },
  NoDataContainer: {
    justifyContent: "space-around",
    alignItems: "center",
    marginTop: 50,
    marginHorizontal: 20,
  },
  NoDataText: {
    fontSize: 18,
    marginBottom: 200,
    color: colors.primary,
    fontFamily: fonts.headerFont,
  },
});
