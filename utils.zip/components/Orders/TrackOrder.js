import AsyncStorage from "@react-native-async-storage/async-storage";
import moment from "moment";
import React, { useEffect, useState } from "react";
import {
    Alert,
    BackHandler,
    Dimensions,
    FlatList,
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from "react-native";
import { Divider } from "react-native-paper";
import StepIndicator from "react-native-step-indicator";
import Icon from "react-native-vector-icons/FontAwesome5";
import { colors, fonts } from "../../constants/GlobalStyles";
import { APIKit } from "../../utils/APIKIT";
import Header from "../Header";

const SCREEN_WIDTH = Dimensions.get("screen").width;

const TrackOrder = ({ route, navigation }) => {
  const { data } = route.params;
  console.log("data", data);

  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };
  useEffect(() => {
    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () =>
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
  }, []);

  let orderStatus = 0;
  if (data.status === "shipped") {
    orderStatus = 2;
  }
  if (data.status === "delivered") {
    orderStatus = 3;
  }
  if (data.status === "canceled") {
    orderStatus = "";
  }
  const [currentPosition, setCurrentPosition] = useState(orderStatus);
  console.log("currentPosition", currentPosition);

  const labels = ["Order", "Shipped", "Delivered"];

  const customStyles = {
    stepIndicatorSize: 25,
    currentStepIndicatorSize: 30,
    separatorStrokeWidth: 2,
    currentStepStrokeWidth: 3,
    stepStrokeCurrentColor: colors.darkOrange,
    stepStrokeWidth: 3,
    stepStrokeFinishedColor: colors.darkOrange,
    stepStrokeUnFinishedColor: "#aaaaaa",
    separatorFinishedColor: colors.darkOrange,
    separatorUnFinishedColor: "#aaaaaa",
    stepIndicatorFinishedColor: colors.darkOrange,
    stepIndicatorUnFinishedColor: "#ffffff",
    stepIndicatorCurrentColor: "#ffffff",
    stepIndicatorLabelFontSize: 13,
    currentStepIndicatorLabelFontSize: 13,
    stepIndicatorLabelCurrentColor: colors.darkOrange,
    stepIndicatorLabelFinishedColor: "#ffffff",
    stepIndicatorLabelUnFinishedColor: "#aaaaaa",
    labelColor: "#999999",
    labelSize: 13,
    labelAlign: "center",
    currentStepLabelColor: colors.darkOrange,
  };

  // let abc = new Date(data.order_details[0].created_at);
  // console.log("abc", abc);
  // let date = new Date(abc.setHours(abc.getHours() + 6));
  // console.log("dateee", date);

  const apiDeleteOrder = async () => {
    let id = await AsyncStorage.getItem("id");
    var dataToSend = {
      user_id: id,
      order_id: data.id,
    };
    console.log("dataToSend", dataToSend);

    APIKit.post("v1/cancel-order", dataToSend)

      .then((response) => {
        if (response.data.code === 400) {
          console.log("responseCancel", response.data);
          Alert.alert("Hello Sir,", response.data.message);
          navigation.goBack();
        } else {
          console.log("error12", response.data);
          Alert.alert("Hello Sir,", response.data.message);
          navigation.navigate("Home");
        }
      })
      .catch((error) => {
        console.log("error221", error);
      });
  };

  const createTwoButtonAlert = () =>
    Alert.alert("Cancel Order", "Are you sure you want to cancel your order?", [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      {
        text: "OK",
        onPress: () => {
          apiDeleteOrder();
        },
      },
    ]);

  const ItemView = ({ item, onPress }) => {
    return (
      <View style={styles.innerContainer}>
        <TouchableOpacity activeOpacity={0.8} style={styles.mainContainer2}>
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <Image
              style={styles.image}
              source={{
                uri: item.product.product_image[0].image,
              }}
         
              resizeMode="stretch"
            />

            <View style={styles.nameText}>
              <View style={styles.header2}>
                <Text style={styles.customerName}>{item.product.name}</Text>
                <View>
                  <Text style={styles.customerOtp}>
                    qty: {item.product_qty}
                  </Text>
                </View>
              </View>
              <View style={styles.header2}>
                <Text style={styles.customerNamemoney}>
                  Variant: {item.variant_name}
                </Text>
                <Text style={styles.price}>
                  Total: {"\u00A3"}
                  {item.product_price * item.product_qty}
                </Text>
              </View>
              <Text style={styles.date}>
                {/* {moment(item.created_at).format("DD-MM-YYYY")} */}
                Price: {"\u00A3"}
                {item.product_price}
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const renderItem = ({ item }) => {
    return <ItemView item={item} />;
  };
  return (
    <View style={styles.container}>
      <Header
        title={"Track Order"}
        isNavigationRequired={true}
        color={"white"}
        backgroundColor={colors.mainHeader}
        height={50}
        right={10}
      />

      <View style={styles.header}>
        <Icon name="calendar-alt" size={18} color={colors.darkOrange} />
        <Text style={styles.datetext}>
          {moment(data.created_at).format("DD-MM-YYYY")}
        </Text>

        <Text style={styles.time}>
          {moment(data.created_at).format("hh:mm A")}
        </Text>
      </View>
      <View style={styles.indicatorStyle}>
        {data.status != "canceled" ? (
          <StepIndicator
            customStyles={customStyles}
            stepCount={3}
            direction={"horizontal"}
            currentPosition={currentPosition}
            labels={labels}
          />
        ) : null}
      </View>
      <View style={{ flex: 1 }}>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={data.order_details}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
        />
        <View style={styles.buttonContainer}>
          <Text style={styles.buttonText}>Total Amount: </Text>
          <Text style={styles.total_amount}>{data.total_amount}</Text>
        </View>
      </View>
      <Divider style={{ borderBottomWidth: 1, borderColor: "grey" }} />
      <View style={{ justifyContent: "flex-end", marginBottom: 10 }}>
        {orderStatus > 0 || data.status === "canceled" ? null : (
          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.buttonContainer2}
            onPress={createTwoButtonAlert}
          >
            <Text style={styles.buttonText2}>Cancel Order</Text>
          </TouchableOpacity>
        )}
        {orderStatus === 3 ? (
          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.reviewContainer}
            onPress={() => {
              navigation.navigate("OrderFeedback", {
                data: data.order_details,
              });
            }}
          >
            <Text style={styles.reviewText}>Write a Review</Text>
          </TouchableOpacity>
        ) : null}
        {data.status === "canceled" ? (
          <View style={styles.cancelContainer}>
            <Text style={styles.cancelText}>This Order has been canceled.</Text>
          </View>
        ) : null}
      </View>
    </View>
  );
};

export default TrackOrder;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.mainBackground,
  },
  header: {
    marginHorizontal: 20,
    marginTop: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  datetext: {
    color: colors.darkOrange,
    marginRight: 140,
    fontWeight: "600",
  },
  time: {
    color: colors.darkOrange,
  },
  indicatorStyle: {
    marginTop: 20,
  },
  innerContainer: {
    marginTop: 5,
    marginHorizontal: 10,
  },
  mainContainer2: {
    height: 80,
    borderWidth: 1,
    backgroundColor: "#fafafa",
    borderColor: "#E8E8E8",
  },
  image: {
    height: 60,
    width: 60,
    marginTop: 9,
    marginLeft: 10,
    borderRadius: 5,
  },
  nameText: {
    width: SCREEN_WIDTH - (60 + 20 + 25),
    marginTop: 5,
    marginHorizontal: 10,
  },
  customerName: {
    fontSize: 16,
    fontWeight: "600",
    color: colors.darkOrange,
    textTransform: "capitalize",
  },
  header2: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: 10,
  },
  customerOtp: {
    fontSize: 12,
    fontWeight: "600",
    color: colors.grey,
    textTransform: "uppercase",
    fontWeight: "bold",
  },
  customerNamemoney: {
    fontSize: 12,
    fontWeight: "600",
    color: colors.grey,
    marginTop: 5,
    textTransform: "uppercase",
  },
  date: {
    color: colors.darkOrange,
    fontSize: 12,
    marginTop: 5,
    marginHorizontal: 10,
  },
  price: {
    color: colors.darkOrange,
    fontWeight: "700",
  },
  buttonContainer: {
    flexDirection: "row",
    marginHorizontal: 20,
    borderRadius: 5,
    height: 50,
    alignItems: "center",
    justifyContent: "flex-end",
  },
  buttonContainer2: {
    marginHorizontal: 20,
    borderRadius: 5,
    backgroundColor: "#FA3E3E",
    borderColor: colors.grey,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
  },
  buttonText: {
    color: "black",
    fontSize: 16,
    fontFamily: fonts.headerFont,
  },
  total_amount: {
    color: colors.darkOrange,
    fontSize: 20,
    fontFamily: fonts.headerFont,
    textDecorationLine: "underline",
  },
  buttonText2: {
    color: "white",
    fontSize: 16,
    fontFamily: fonts.headerFont,
  },
  reviewContainer: {
    // borderWidth: 1,
    marginHorizontal: 20,
    borderRadius: 5,
    backgroundColor: "#5D2DE3",
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
  },
  reviewText: {
    fontSize: 16,
    color: "white",
    fontFamily: fonts.headerFont,
    // textDecorationLine: "underline",
  },
  cancelContainer: {
    marginHorizontal: 20,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
  },
  cancelText: {
    color: "red",
    fontSize: 16,
    fontFamily: fonts.headerFont,
    // textDecorationLine: "underline",
  },
});
