import React, { useEffect, useState } from 'react';
import { BackHandler, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { colors } from '../../constants/GlobalStyles';
import { apiGeneralSetting } from '../../utils/APIKIT';
import Header from '../Header';

const About = ({navigation, route}) => {
  const [data, setData] = useState([]);

  const GeneralSetting = async () => {
    let response = await apiGeneralSetting();
    if (response.error) {
      console.log('responseGeneralSetting11', response.data.code);
      navigation.navigate('LoginScreen');
    } else {
      console.log('responseGeneralSetting22', response.data.result);
      setData(response.data.result);
    }
  };

  useEffect(() => {
    GeneralSetting()
  }, []);

  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };
  useEffect(() => {
    BackHandler.addEventListener('hardwareBackPress', handleBackPress);

    return () =>
      BackHandler.removeEventListener('hardwareBackPress', handleBackPress);
  }, []);

  return (
    <View style={{flex: 1}}>
      <Header
        title={'About'}
        isNavigationRequired={true}
        color={'white'}
        backgroundColor={colors.mainHeader}
        height={50}
        left={5}
      />
      <View style={{width: '100%', height: '100%'}}>
        <WebView
          source={{
            uri: data.about_us,
          }}
        />
      </View>
    </View>
  );
};

export default About;
