import React, { useEffect, useState } from "react";
import { BackHandler, View } from "react-native";
import { WebView } from "react-native-webview";
import { colors } from "../../constants/GlobalStyles";
import { apiGeneralSetting } from "../../utils/APIKIT";
import Header from "../Header";

const PrivacyPolicy = ({ navigation }) => {

  const [data, setData] = useState([])

  const GeneralSetting = async () => {
    let response = await apiGeneralSetting();
    if (response.error) {
      console.log('responseGeneralSetting11', response.data.code);
      navigation.navigate('LoginScreen');
    } else {
      console.log('responseGeneralSetting22', response.data.result);
      setData(response.data.result);
    }
  };

  useEffect(() => {
    GeneralSetting()
  }, []);

  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };
  useEffect(() => {
    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () =>
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
  }, []);

  return (
    <View style={{ flex: 1 }}>
      <Header
        title={"Privacy Policy"}
        isNavigationRequired={true}
        color={"white"}
        backgroundColor={colors.mainHeader}
        height={50}
      />
      <View style={{ width: "100%", height: "100%" }}>
        <WebView
          source={{
            uri: data.privacy_policy,
            // uri: "https://www.termsfeed.com/live/14acbc8f-6c82-4d3f-bf53-e68435d509b2",
          }}
        />
      </View>
    </View>
  );
};

export default PrivacyPolicy;
