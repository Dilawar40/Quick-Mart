import React, { useState } from "react";
import { View, Text, Image, StyleSheet } from "react-native";
import { Dimensions } from "react-native";
import Carousel, { Pagination } from "react-native-snap-carousel";
import { TouchableOpacity } from "react-native-gesture-handler";

const SCREEN_WIDTH = Dimensions.get("screen").width;
const BannerHeight = ((SCREEN_WIDTH - 40) * 168) / 335;

const ImageSection = ({ data }) => {
  const [activeSlide, setActiveSlide] = useState(0);

  const renderItem = ({ item }) => {
    return (
      <View style={{}}>
        <View
          style={{
            width: "100%",
            height: BannerHeight,
          }}
        >
          <TouchableOpacity activeOpacity={0.8} onPress={() => {}}>
            <Image
              style={{
                height: BannerHeight,
                resizeMode: "center",
              }}
              source={{ uri: item.image }}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  const pagination = () => {
    return (
      <Pagination
        dotsLength={data.product_image.length}
        activeDotIndex={activeSlide}
        dotStyle={styles.carousalDotStyle}
        inactiveDotOpacity={0.4}
        inactiveDotScale={0.6}
      />
    );
  };
  return (
    <>
      <Carousel
        data={data.product_image}
        vertical={false}
        activeSlideAlignment={"center"}
        renderItem={renderItem}
        onSnapToItem={(index) => setActiveSlide(index)}
        sliderWidth={SCREEN_WIDTH}
        itemWidth={SCREEN_WIDTH * 0.9}
        containerCustomStyle={styles.customStyle}
        // enableSnap={false}
      />
      {pagination()}
    </>
  );
};

export default ImageSection;

const styles = StyleSheet.create({
  carousalDotStyle: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 5,
    backgroundColor: "green",
  },
  customStyle: {
    flexGrow: 0,
    marginTop: 10,
  },
});
