import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { colors } from "../../constants/GlobalStyles";

const ContentSection = ({
  data,
  variant1Pressed,
  variant2Pressed,
  variant3Pressed,
}) => {
  return (
    <View style={styles.container}>
      {variant1Pressed ? (
        <View>
          <Text style={styles.HeaderText}>
            {data.variant ? data.name : null}
          </Text>
          <View style={styles.priceContainer}>
            <Text style={styles.priceText}>
              ₹{data.variant ? data.variant[0].price : null}
            </Text>
            <Text style={styles.labelText}>
              {" "}
              / {data.variant ? data.variant[0].name : null}
            </Text>
          </View>
          <Text style={styles.labelText}>
            ₹{data.variant ? data.variant[0].gst_price : null} VAT included
          </Text>
        </View>
      ) : null}
      {variant2Pressed ? (
        <View>
          <Text style={styles.HeaderText}>
            {data.variant ? data.name : null}
          </Text>
          <View style={styles.priceContainer}>
            <Text style={styles.priceText}>
              ₹{data.variant ? data.variant[1].price : null}
            </Text>
            <Text style={styles.labelText}>
              {" "}
              / {data.variant ? data.variant[1].name : null}
            </Text>
          </View>
          <Text style={styles.labelText}>
            {"\u00A3"}{data.variant ? data.variant[1].gst_price : null} VAT included
          </Text>
        </View>
      ) : null}
      {variant3Pressed ? (
        <View>
          <Text style={styles.HeaderText}>
            {data.variant ? data.name : null}
          </Text>
          <View style={styles.priceContainer}>
            <Text style={styles.priceText}>
              ₹{data.variant ? data.variant[2].price : null}
            </Text>
            <Text style={styles.labelText}>
              {" "}
              / {data.variant ? data.variant[2].name : null}
            </Text>
          </View>
          <Text style={styles.labelText}>
            {"\u00A3"}{data.variant ? data.variant[2].gst_price : null} VAT included
          </Text>
        </View>
      ) : null}
    </View>
  );
};

export default ContentSection;

const styles = StyleSheet.create({
  container: {
    // marginTop: 10,
    marginHorizontal: 20,
  },
  HeaderText: {
    fontSize: 20,
    fontWeight: "800",
    marginTop: 10,
    textTransform: "capitalize",
  },
  desText: {
    fontSize: 16,
    marginTop: 10,
  },
  priceContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  priceText: {
    fontSize: 20,
    marginTop: 10,
    fontWeight: "800",
    color: colors.primary,
  },
  labelText: {
    fontSize: 12,
    marginTop: 12,
  },
});
