import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  FlatList,
} from "react-native";
import React, { useState } from "react";
import { colors } from "../../constants/GlobalStyles";
import QtySection from "./QtySection";
import QtySection2 from "./QtySection2";
import QtySection3 from "./QtySection3";

const VariantSection = ({
  data,
  variant1Pressed,
  variant2Pressed,
  variant3Pressed,
  setVariant1Pressed,
  setVariant2Pressed,
  setVariant3Pressed,
}) => {
  return (
    <View style={styles.container}>
      <Text style={styles.variant}>Variant</Text>

      <View>
        <ScrollView contentContainerStyle={{ alignItems: "center" }}>
          <View style={styles.buttonsContainer}>
            <View style={styles.buttonsRowView}>
              <TouchableOpacity
                style={
                  variant1Pressed
                    ? styles.pressedButtonRipple
                    : styles.buttonRipple
                }
                onPress={() => {
                  setVariant1Pressed(true);
                  setVariant2Pressed(false);
                  setVariant3Pressed(false);
                }}
              >
                <View style={styles.rippleView}>
                  <Text
                    style={
                      variant1Pressed
                        ? styles.pressedButtontitle
                        : styles.buttontitle
                    }
                  >
                    {data.variant
                      ? data.variant[0].name
                      : data.order_details[0].product_variant.name}
                  </Text>
                </View>
              </TouchableOpacity>
              {data.variant
                ? data.variant.length > 1 && (
                    <TouchableOpacity
                      style={
                        variant2Pressed
                          ? styles.pressedButtonRipple
                          : styles.buttonRipple
                      }
                      onPress={() => {
                        setVariant2Pressed(true);
                        setVariant1Pressed(false);
                        setVariant3Pressed(false);
                      }}
                    >
                      <View style={styles.rippleView}>
                        <Text
                          style={
                            variant2Pressed
                              ? styles.pressedButtontitle
                              : styles.buttontitle
                          }
                        >
                          {data.variant
                            ? data.variant[1].name
                            : data.order_details[1].product_variant.name}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  )
                : null}
              {data.variant
                ? data.variant.length > 2 && (
                    <TouchableOpacity
                      style={
                        variant3Pressed
                          ? styles.pressedButtonRipple
                          : styles.buttonRipple
                      }
                      onPress={() => {
                        setVariant3Pressed(true);
                        setVariant1Pressed(false);
                        setVariant2Pressed(false);
                      }}
                    >
                      <View style={styles.rippleView}>
                        <Text
                          style={
                            variant3Pressed
                              ? styles.pressedButtontitle
                              : styles.buttontitle
                          }
                        >
                          {data.variant
                            ? data.variant[2].name
                            : data.order_details[2].product_variant.name}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  )
                : null}
            </View>
          </View>
        </ScrollView>
      </View>
      <View style={styles.bottomline} />
      {variant1Pressed ? (
        <QtySection data={data} />
      ) : variant2Pressed ? (
        <QtySection2 data={data} />
      ) : variant3Pressed ? (
        <QtySection3 data={data} />
      ) : null}
    </View>
  );
};

export default VariantSection;

const styles = StyleSheet.create({
  container: {
    marginTop: 10,
    marginHorizontal: 20,
  },
  variant: {
    fontWeight: "600",
    marginTop: 10,
  },
  buttonsContainer: {
    alignItems: "center",
    width: "95%",
    margin: 5,
    justifyContent: "center",
  },
  buttonsRowView: {
    flexDirection: "row",
    alignItems: "center",
    height: "90%",
    width: "95%",
  },
  buttonRipple: {
    width: "30%",
    height: 35,
    marginHorizontal: 5,
    borderWidth: 1,
    borderColor: colors.grey,
    marginVertical: "3%",
  },
  pressedButtonRipple: {
    width: "30%",
    height: 35,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: "green",
    marginHorizontal: 10,
  },
  variantButton: {
    marginVertical: 10,
    borderWidth: 1,
    borderColor: "green",
    marginHorizontal: 10,
  },
  buttontitle: {
    fontSize: 16,
    color: colors.grey,
    fontFamily: "Lexend-Medium",
    fontWeight: "600",
    padding: 5,
  },
  pressedButtontitle: {
    fontSize: 16,
    color: "green",
    fontFamily: "Lexend-Medium",
    fontWeight: "700",
  },
  rippleView: {
    height: "100%",
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    // borderWidth: 1,
    // borderColor: colors.grey,
  },
  bottomline: {
    borderBottomWidth: 1,
    borderBottomColor: colors.lightgrey,
  },
});
