import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useState } from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Toast from "react-native-toast-message";
import Icon from "react-native-vector-icons/MaterialIcons";
import { colors } from "../../constants/GlobalStyles";
import { APIKit } from "../../utils/APIKIT";

const QtySection2 = ({ data, index }) => {
  console.log("qty section2", data);

  let [num, setNum] = useState(0);
  const [selectedItem, setSelectedItem] = useState([]);
  const [items, setItems] = useState();

  // useEffect(() => {
  //   AsyncStorage.setItem("quantity", JSON.stringify(items));
  // }, [items]);

  // useEffect(() => {
  //   {
  //     data.variant[1].qty === 0
  //       ? null
  //       : setTimeout(() => {
  //           AddCart();
  //         }, 100);
  //   }
  // }, [data.variant[1].qty]);

  const AddCart = async (selected) => {
    console.log("selectedItem", selectedItem);
    let id = await AsyncStorage.getItem("id");
    var dataToSend = {
      user_id: id,
      product_id: selected.variant[1].product_id,
      product_variant_id: selected.variant[1].id,
      qty: selected.variant[1].qty,
    };
    console.log("dataToSend", dataToSend);
    APIKit.post("v1/add-cart", dataToSend)
      .then((response) => {
        TostMessage();
        AsyncStorage.setItem("quantity", response.data.total_items);
        // console.log("addcart2", response.data);
        if (response) {
          // console.log("responseAddCart", response.data);
        }
      })
      .catch((error) => {
        console.log("error222", error);
      });
  };
  const TostMessage = () => {
    Toast.show({
      type: "success",
      text1: "Success",
      text2: "Your Product is updated in the cart...!!!",
      topOffset: 80,
      visibilityTime: 1000,
    });
  };
  const incNum = (type, value, index) => {
    setNum(num + 1);
    // setItems(num + 1);
    data.variant[1].qty += 1;
  };
  const decNum = (type, value, index) => {
    setNum(num - 1);
    // setItems(num - 1);
    if (data.variant[1].qty > 0) {
      data.variant[1].qty -= 1;
    }
  };
  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.desText} numberOfLines={12}>
          {data.order_details
            ? data.order_details[1].product.description
            : data.description}
        </Text>
      </View>
      <View>
        {data.product_image.length > 1 ? (
          <View style={styles.qtyContainer}>
            <Text style={styles.desText}>Quantity</Text>
            <View style={styles.plusminus}>
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.actionBtn}
                onPress={(text) => {
                  decNum("qty", text, index);
                  AddCart(data);
                }}
              >
                <Icon name="remove" size={25} color={colors.white} />
              </TouchableOpacity>
              <View style={styles.actionBtn2}>
                <Text style={{ fontWeight: "600" }}>{data.variant[1].qty}</Text>
              </View>
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.actionBtn}
                onPress={(text) => {
                  incNum("qty", text, index);
                  AddCart(data);
                }}
              >
                <Icon name="add" size={25} color={colors.white} />
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.qtyContainer2}>
            <Text style={styles.desText}>Quantity</Text>
            <View style={styles.plusminus}>
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.actionBtn}
                onPress={(text) => {
                  decNum("qty", text, index);
                  AddCart(data);
                }}
              >
                <Icon name="remove" size={25} color={colors.white} />
              </TouchableOpacity>
              <View style={styles.actionBtn2}>
                <Text style={{ fontWeight: "600" }}>{data.variant[1].qty}</Text>
              </View>
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.actionBtn}
                onPress={(text) => {
                  incNum("qty", text, index);
                  AddCart(data);
                }}
              >
                <Icon name="add" size={25} color={colors.white} />
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
    </View>
  );
};

export default QtySection2;

const styles = StyleSheet.create({
  container: {
    marginTop: 10,
    marginHorizontal: 20,
  },
  desText: {
    fontSize: 16,
    marginTop: 10,
  },
  qtyContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    marginTop: 30,
    marginBottom: 10,
  },
  qtyContainer2: {
    flexDirection: "row",
    position: "relative",
    justifyContent: "space-around",
    alignItems: "center",
    marginTop: 80,
    marginBottom: 10,
  },
  plusminus: {
    flexDirection: "row",
    borderWidth: 1,
    borderColor: "lightgrey",
    width: 152.5,
    marginTop: 15,
    marginLeft: 35,
  },
  actionBtn: {
    width: 50,
    height: 30,
    backgroundColor: colors.primary,
    justifyContent: "center",
    alignItems: "center",
  },
  actionBtn2: {
    width: 50,
    height: 30,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
  },
});
