import { useNavigation } from '@react-navigation/native';
import React, { useEffect } from 'react';
import {
  BackHandler,
  Dimensions,
  FlatList,
  Image,
  Text,
  TouchableOpacity,
  View
} from 'react-native';
import styles from '../../screens/SupplierListScreen/style';

const SCREEN_WIDTH = Dimensions.get('screen').width;

const CompanySupplierList = ({ data }) => {
  const navigation = useNavigation();

  useEffect(() => {
    BackHandler.addEventListener('hardwareBackPress', handleBackPress);
    return () =>
      BackHandler.removeEventListener('hardwareBackPress', handleBackPress);
  }, []);
  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };
  const ItemView = ({ item, onPress }) => {
    return (
      <View style={styles.innerContainer}>
        <TouchableOpacity
          activeOpacity={0.8}
          style={styles.mainContainer2}
          onPress={onPress}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Image
              style={styles.image}
              source={
                item.image
                  ? { uri: item.image }
                  : require('../../Assets/logo.png')
              }
              resizeMode="contain"
            />
            <View style={styles.nameText}>
              <View style={styles.header}>
                <Text style={styles.customerName}>{item.name}</Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                <Text style={styles.customerNamemoney}>
                  {/* order status:{" "} */}
                  Phone no : {item.mobile}
                </Text>
              </View>
              <Text style={styles.date}>
                {item.address.slice(0, 33)}
                {
                  item.address.length > 32 ? '...' : null
                }
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const renderView = ({ item }) => {
    return (
      <ItemView
        item={item}
        onPress={() => {
          navigation.navigate('HistoryItemsSupplier', {
            historyData: item,
          });
        }}
      />
    );
  };
  return (
    <View>
      {data.code === 400 ? (
        <View style={styles.NoDataContainer}>
          <Image
            source={require('../../Assets/history.jpg')}
            resizeMode="center"
            style={{ height: '100%', width: '100%' }}
          />
          <Text style={styles.NoDataText}>The product is not available</Text>
        </View>
      ) : (
        <View style={{ paddingBottom: '20%' }}>
          <FlatList data={data?.result} renderItem={renderView} />
        </View>
      )}
    </View>
  );
};
export default CompanySupplierList;
