

import React, {useState} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {View, Text, Button} from 'react-native';
import About from '../Settings/About';

const HomeScreen = ({navigation}) => (
  <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
    <Text>Home Screen</Text>
    <Button title="Open Drawer" onPress={() => navigation.openDrawer()} />
  </View>
);

const OtherScreen = ({navigation}) => (
  <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
    <Text>Other Screen</Text>
    <Button title="Open Drawer" onPress={() => navigation.openDrawer()} />
  </View>
);

const Drawer = createDrawerNavigator();

const App = () => {
  const [showDrawerButton, setShowDrawerButton] = useState(false);

  return (
    <Drawer.Navigator
      drawerPosition="right" // Set the drawer position to the right
    >
      <Drawer.Screen
        name="Home"
        component={HomeScreen}
        options={{headerShown: false}} // Hide header for HomeScreen
      />
      <Drawer.Screen
        name="about"
        component={About}
        options={{headerShown: false}} // Hide header for OtherScreen
      />
    </Drawer.Navigator>
  );
};

export default App;
