import React from "react";
import { Text, View, TextInput, StyleSheet } from "react-native";

const PrimaryInputForm = (props) => {
  const {
    placeHolderText,
    secureTextEntry,
    value,
    onChangeText,
    keyboardType,
  } = props;
  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          style={{
            marginLeft: 5,
            // fontSize: 14,
          }}
          placeholder={placeHolderText}
          secureTextEntry={secureTextEntry}
          value={value}
          onChangeText={onChangeText}
          keyboardType={keyboardType}
        />
      </View>
    </View>
  );
};

export default PrimaryInputForm;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  inputContainer: {
    borderWidth: 0.5,
    borderColor: "gray",
    borderRadius: 10,
    height: 50,
    width: "100%",
    justifyContent: "center",
    backgroundColor: "#fff",
    // elevation: 10,
  },
});
