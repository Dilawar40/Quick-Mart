import React, {useEffect, useState} from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {colors} from '../../constants/GlobalStyles';
import {
  apiGetSupplierHistory,
  apiGetSuppliersDataHistory,
} from '../../utils/APIKIT';
import HistoryItemsSuppliers from './HistoryItemsSupplier';
import OngoingItemsSupplier from './OngoingItemsSupplier';
import CompanySupplierList from '../comapanies/CompanySupplierList';

const OrderButtonSupplier = ({onPress, Press, orderData}) => {
  const [ongoingPressed, setOnGoingPressed] = useState(true);
  const [historyPressed, setHistoryPressed] = useState(false);
  const [historyData, setHistoryData] = useState([]);
  useEffect(() => {
    setTimeout(() => {
      FetchHistory();
    }, 100);
  }, []);
  const FetchHistory = async () => {
    let response = await apiGetSuppliersDataHistory()
      .then(function (response) {
        // console.log(response);
        if (response) {
        //   console.log('responseHistory', response.data.result);
          setHistoryData(response.data);
        } else {
        //   console.log('responseHistoryError', response.data.message);
        }
      })
      .catch(function (error) {
        // handle error
        if (error.response.status === 401) {
          console.log('Token Expire goto login screen');
          navigation.navigate('LoginScreen');
        } else {
          console.log('Other error show it to user');
        }
      });
  };
  return (
    <View style={styles.container}>
      <View>
        <ScrollView contentContainerStyle={{alignItems: 'center'}}>
          <View style={styles.buttonsContainer}>
            <View style={styles.buttonsRowView}>
              <TouchableOpacity
                style={
                  ongoingPressed
                    ? styles.pressedButtonRipple
                    : styles.buttonRipple
                }
                onPress={() => {
                  setOnGoingPressed(true);
                  setHistoryPressed(false);
                }}>
                <View style={styles.rippleView}>
                  <Text
                    style={
                      ongoingPressed
                        ? styles.pressedButtontitle
                        : styles.buttontitle
                    }>
                    Ongoing
                  </Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={
                  historyPressed
                    ? styles.pressedButtonRipple
                    : styles.buttonRipple
                }
                onPress={() => {
                  setHistoryPressed(true);
                  setOnGoingPressed(false);
                }}>
                <View style={styles.rippleView}>
                  <Text
                    style={
                      historyPressed
                        ? styles.pressedButtontitle
                        : styles.buttontitle
                    }>
                    History
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
      <View style={styles.bottomline} />
      {ongoingPressed ? (
        <OngoingItemsSupplier orderData={orderData} />
      ) : historyPressed ? (
        <CompanySupplierList data={historyData} />
      ) : null}
    </View>
  );
};

export default OrderButtonSupplier;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  buttonsContainer: {
    alignItems: 'center',
    width: '95%',
    margin: 5,
    justifyContent: 'center',
  },
  buttonsRowView: {
    flexDirection: 'row',
    alignItems: 'center',
    // backgroundColor: "lightgray",
    borderRadius: 10,
    height: '90%',
    width: '95%',
    justifyContent: 'space-around',
  },
  buttonRipple: {
    width: '30%',
    height: 35,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: 8,
    marginVertical: '3%',
    marginHorizontal: 3,
  },
  pressedButtonRipple: {
    width: '30%',
    height: 35,
    borderRadius: 8,
    marginVertical: '3%',
    backgroundColor: colors.primary,
    marginHorizontal: 5,
  },
  buttontitle: {
    fontSize: 14,
    color: colors.primary,
    fontFamily: 'Lexend-Medium',
  },
  pressedButtontitle: {
    fontSize: 14,
    color: 'white',
    fontFamily: 'Lexend-Medium',
  },
  rippleView: {
    height: '100%',
    width: '100%',
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomline: {
    borderBottomWidth: 2,
    borderBottomColor: 'lightgray',
    bottom: 5,
  },
});
