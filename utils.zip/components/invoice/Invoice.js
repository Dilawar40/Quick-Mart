import React from 'react';
import { FlatList, Image, StyleSheet, Text, View } from 'react-native';

import { useRoute } from '@react-navigation/native';
import { colors } from '../../constants/GlobalStyles';
import Header from '../Header';

const Invoice = () => {

  const route = useRoute()

  const { item22 } = route.params


  // console.log('iteeeem', item22)

  const [data, setData] = ([
    { name: 'Product 1', quantity: 2, rate: 10 },
    { name: 'Product 2', quantity: 1, rate: 15 },
    { name: 'Product 3', quantity: 3, rate: 12 },])
  const products = [
    { name: 'Product 1', quantity: 2, rate: 10 },
    { name: 'Product 2', quantity: 1, rate: 15 },
    { name: 'Product 3', quantity: 3, rate: 12 },
  ];
  const renderItem = ({ item }) => {
    console.log('eeeeeeeeeeeeeeeeeeee', item)
    return (
      <View style={{
        // backgroundColor: 'pink',
        justifyContent: 'space-between',
        marginHorizontal: '10%',
        // marginTop: '10%',
        marginTop: '3%',

        flexDirection: 'row'
      }}>
        <View style={{ left: '5%' }}>
          <Text style={{ color: 'black', fontSize: 15 }}>Item</Text>
        </View>
        <View style={{ flexDirection: 'row' }}>
          <Text style={{ color: 'black', fontSize: 17, marginRight: 20 }}>{item.quantity}.00</Text>
          <Text style={{ color: 'black', fontSize: 17, }}>£{item.rate}.00</Text>
        </View>
      </View>
    )
  }
  return (
    <View style={{ flex: 1 }}>
      <Header
        title={"Track Order"}
        isNavigationRequired={true}
        color={"white"}
        backgroundColor={colors.mainHeader}
        height={50}
        right={10}
      />
      <View style={{ height: '10%', justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ fontSize: 40, fontWeight: '700', color: 'black', marginTop: '5%' }}>INVOICE</Text>
      </View>
      <View style={{ marginTop: '10%', marginLeft: '5%', flexDirection: 'row', justifyContent: 'space-between', marginHorizontal: '15%' }}>
        <View style={{ left: '15%' }}>
          <Text style={{ color: 'black', fontSize: 20 }}>Name</Text>
          <Text style={{ color: 'black', fontSize: 20 }}>Address</Text>
          <Text style={{ color: 'black', fontSize: 20 }}>Order no</Text>
        </View>
        <View>
          <Image source={require('../../Assets/4.jpg')}
            style={{ width: 70, height: 70, borderRadius: 20 }}
          />
        </View>
      </View>
      <View style={{ marginTop: '5%', marginLeft: '10%' }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ color: 'black', fontSize: 17 }}>Invoice no : </Text>
          <Text style={{ color: 'black', fontSize: 20 }}>12345676543</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ color: 'black', fontSize: 16 }}>Date at : </Text>
          <Text style={{ color: 'black', fontSize: 20 }}>{item22.created_at.slice(0, 10)}</Text>
        </View>
      </View>
      <View style={{
        backgroundColor: 'grey',
        justifyContent: 'space-between',
        marginHorizontal: '10%',
        marginTop: '10%',

        flexDirection: 'row'
      }}>
        <View style={{ left: '5%' }}>
          <Text style={{ color: 'white', fontSize: 16 }}>ITEM</Text>
        </View>
        <View style={{ flexDirection: 'row', left: '4%' }}>
          <Text style={{ color: 'white', fontSize: 16, marginRight: '10%' }}>RATE</Text>
          <Text style={{ color: 'white', fontSize: 16, }}>AMOUNT</Text>
        </View>
      </View>
      <View style={{}}>
        <FlatList
          data={item22}
          renderItem={renderItem}
        />
      </View>

      {/* <View style={{backgroundColor:'pink',justifyContent:'space-evenly',marginRight:'5%',marginTop:'5%',marginLeft:'5%',flexDirection:'row'}}>
       <Text style={{color:'black',fontSize:20}}>Sugar</Text>
            <Text style={{color:'black',fontSize:20}}>Quantity</Text>
            <Text style={{color:'black',fontSize:20}}>Price</Text>
       
        </View> */}
      <View style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        borderRightColor: 'pink',
        marginTop: '5%',
        marginLeft: '5%',
        marginHorizontal: '7%',
        borderTopColor: 'lightgrey',
        borderTopWidth: 7,
        borderBottomColor: 'lightgrey',
        borderBottomWidth: 7,
      }}>
        <Text style={{ fontSize: 20, marginLeft: 10, color: 'black' }}>Total</Text>
        <Text style={{ fontSize: 20, marginRight: 15, color: 'black' }}>£115</Text>
      </View>
      {/* <View style={{backgroundColor:'red',flexDirection:'row',justifyContent:'space-between'}}> */}
      <View style={{ justifyContent: 'space-between', borderRightColor: 'pink', marginTop: '5%', marginLeft: '40%', marginHorizontal: '7%' }}>
        <View style={{ justifyContent: 'space-between', flexDirection: 'row' }}>
          <Text>SUBTOTAL</Text>
          <Text>1000</Text>
        </View>
        <View style={{ justifyContent: 'space-between', flexDirection: 'row' }}>
          <Text>Discount</Text>
          <Text>1000</Text>
        </View>
        <View style={{ justifyContent: 'space-between', flexDirection: 'row' }}>
          <Text>SVAT</Text>
          <Text>1000</Text>
        </View>
        <View style={{ justifyContent: 'space-between', flexDirection: 'row' }}>
          <Text>CVAT</Text>
          <Text>1000</Text>
        </View>
        <View style={{ justifyContent: 'space-between', marginTop: '2%', flexDirection: 'row' }}>
          <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Total</Text>
          <Text style={{ fontSize: 20, fontWeight: 'bold' }}>£ 4000</Text>
        </View>
      </View>
    </View>
    // </View>
  )
}

export default Invoice

const styles = StyleSheet.create({})