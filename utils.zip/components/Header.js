import { useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import {
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from "react-native";

import Icon from "react-native-vector-icons/FontAwesome5";
import Ionicons from "react-native-vector-icons/Ionicons";
import { fonts } from "../constants/GlobalStyles";

const Header = ({
  title,
  isNavigationRequired,
  color,
  isSearchRequired,
  SearchColor,
  onPress,
  value,
  renderItem,
  onChangeText,
  isEditRequired,
  editcolor,
  data,
  bgcolor,
  backgroundColor,
  height,
  titleright,
  right,
  titleleft,
  left,
}) => {
  const navigation = useNavigation();
  const [SearchPressed, setSearchPressed] = useState(false);

  // const SearchHandle = () => {
  //   setSearchPressed(false);
  // }


  const openDrawer = () => {
    navigation.openDrawer();
  };
  return (
    <View
      style={[
        styles.container,
        (bgcolor = { backgroundColor }),
        (height = { height }),
      ]}
    >
      <View style={styles.inputContainerLayout}>
        {isNavigationRequired ? (
          <TouchableOpacity
            activeOpacity={0.6}
            style={{ height: 30, width: 30, marginTop: 5 }}
            onPress={() => navigation.goBack()}
          >
            <Icon name="arrow-left" size={20} color={color} />
          </TouchableOpacity>
        ) : (

          // <TouchableOpacity onPress={() => openDrawer()}
          // >
          //   <Iconics name="reorder-three" size={20} color={color} />
          // </TouchableOpacity>

          <Image
            style={{ width: 35, height: 22 }}
            source={require("../Assets/logo2.jpg")}
          />
        )}

        <Text
          style={[
            styles.inputTitle,
            (color = { color }),
            (titleright = { right }),
            (titleleft = { left }),
          ]}
        >
          {title}
        </Text>
        <View style={{ left: 70 }}>
          {!isNavigationRequired ? (

            <TouchableOpacity onPress={() => openDrawer()}
            >
              <Ionicons name="reorder-three" size={25} color={'white'} />
            </TouchableOpacity>
          ) : null}
          {/* {1 ==1 ? (
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() =>
                navigation.navigate("EditInvoiceScreen", {
                  data: data,
                })
              }
            >
              <Icon name="edit" size={18} color={editcolor} />
            </TouchableOpacity>
          ) : null} */}
        </View>
        <View style={styles.search}>
          {isSearchRequired ? (
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => {
                setSearchPressed(true);
                {
                  SearchPressed ? setSearchPressed(false) : null;
                }
              }}
            >
              <Icon name="search" size={18} color={SearchColor} />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      {/* {SearchPressed && onPress ? (
        <View style={{ flexDirection: "row", height: 70 }}>
          <TextInput
            style={styles.TextInputStyle}
            value={value}
            renderItem={renderItem}
            placeholder="Search here..."
            underlineColorAndroid="transparent"
            onChangeText={onChangeText}
          />
          <Icon
            name="search"
            size={18}
            color="gray"
            style={{ top: 25, right: 50 }}
          />
        </View>
      ) : null}
       */}

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    // flex: 1,
  },
  inputContainerLayout: {
    flexDirection: "row",
    paddingLeft: 20,
    marginTop: 20,
    bottom: 10,
    alignItems: "center",
    justifyContent: "space-between",
  },
  inputTitle: {
    fontSize: 20,
    fontFamily: fonts.headerFont,
    paddingLeft: 38,
    fontWeight: "500",
    marginBottom: 5,
  },
  search: {
    marginRight: 20,
  },
  TextInputStyle: {
    backgroundColor: "white",
    width: "90%",
    borderRadius: 5,
    height: 50,
    borderWidth: 1,
    paddingLeft: 15,
    borderColor: "#F8F8F8",
    marginHorizontal: 20,
    top: 10,
  },
});
export default Header;
