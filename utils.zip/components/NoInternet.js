import { StyleSheet, Text, View, Image } from "react-native";
import React, { useEffect, useState } from "react";
import NetInfo from "@react-native-community/netinfo";
import { fonts } from "../constants/GlobalStyles";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";

const NoInternet = ({ top }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [show, setShow] = useState(false);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      console.log("Connection type", state.type);
      console.log("Is connected?", state.isConnected);
      setIsConnected(state.isConnected);
      {
        state.isConnected === true ? null : setShow(true);
      }
      setTimeout(() => {
        setShow(false);
      }, 5000);
    });

    return () => {
      unsubscribe();
    };
  }, []);
  return (
    <View>
      {show == true ? (
        <View
          style={{
            position: "absolute",
            bottom: 0,
            height: 50,
            width: "100%",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "row",
            backgroundColor: isConnected ? "green" : "black",
          }}
        >
          <Icon
            name={isConnected ? "wifi" : "wifi-off"}
            size={20}
            color={isConnected ? "white" : "red"}
          />
          <Text
            style={{
              color: "white",
              fontFamily: fonts.headerFont,
              marginLeft: 5,
            }}
          >
            {isConnected ? "Online" : "No Internet Connection"}
          </Text>
        </View>
      ) : null}
    </View>
  );
};

export default NoInternet;

const styles = StyleSheet.create({});
