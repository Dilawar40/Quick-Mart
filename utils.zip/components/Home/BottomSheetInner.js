import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {useState} from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Toast from 'react-native-toast-message';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {colors} from '../../constants/GlobalStyles';
import {APIKit} from '../../utils/APIKIT';

const SCREEN_WIDTH = Dimensions.get('screen').width;

const BottomSheetInner = ({item, height}) => {
  // console.log("item", item);
  let [num, setNum] = useState(0);
  const [items, setItems] = useState([]);

  // useEffect(() => {
  //   // console.log("selectedItem", items);
  //   AsyncStorage.setItem("quantity", JSON.stringify(items));
  // }, [items]);

  // console.log("123123", items);

  const AddCart = async selected => {
    console.log('selected', selected);
    let id = await AsyncStorage.getItem('id');
    var dataToSend = {
      user_id: id,
      product_id: selected.product_id,
      product_variant_id: selected.id,
      qty: selected.qty,
    };
    // console.log("dataToSend", dataToSend);
    APIKit.post('v1/add-cart', dataToSend)
      .then(response => {
        AsyncStorage.setItem('quantity', response.data.total_items);
        // console.log("addcart2", response.data);
        TostMessage(response.data.message);
        if (response) {
          // console.log("responseAddCart", response.data);
        }
      })
      .catch(error => {
        console.log('error222', error);
      });
  };
  const incNum = (type, value, index) => {
    // console.log("inc", index);
    setNum(num + 1);
    item.variant[index].qty += 1;
    // setItems(num + 1);
  };
  const decNum = (type, value, index) => {
    // console.log("dec", index);
    setNum(num - 1);
    // setItems(num - 1);
    if (item.variant[index].qty > 0) {
      item.variant[index].qty -= 1;
    }
  };

  const TostMessage = item => {
    Toast.show({
      type: 'success',
      text1: 'Success',
      text2: item,
      topOffset: 80,
      visibilityTime: 1000,
    });
  };
  const RenderItem = ({item, index}) => {
    return (
      <View key={index} style={styles.panel}>
        <View style={styles.cartCard2}>
          <View style={styles.innerHeader}>
            <View style={styles.nameText}>
              <Text
                style={{
                  fontWeight: 'bold',
                  fontSize: 16,
                  textTransform: 'uppercase',
                }}>
                {item.name}
              </Text>
              {/* <Text style={styles.innerPrice}>MRP ₹{item.price}</Text> */}
            </View>
            <Text style={styles.innerPrice}>MRP ₹{item.price}</Text>
            <Text
              style={{
                fontWeight: '600',
                fontSize: 12,
                color: 'grey',
                // marginTop: 10,
              }}>
              {item.gst_price > 0 ? '£' + item.gst_price : 'No'} VAT included
              {/* {item.gst_price} GST included */}
            </Text>
            <View style={styles.handle}>
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.actionBtn}
                onPress={text => {
                  decNum('qty', text, index);
                  AddCart(item);
                }}>
                <Icon name="remove" size={25} color={colors.white} />
              </TouchableOpacity>
              <View style={styles.actionBtn2}>
                <Text style={{fontWeight: '600'}}>{item.qty}</Text>
              </View>
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.actionBtn}
                onPress={text => {
                  incNum('qty', text, index);
                  AddCart(item);
                }}>
                <Icon name="add" size={25} color={colors.white} />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View
      style={{
        backgroundColor: colors.white,
        paddingVertical: 5,
        // height: item.variant > [0] && item.variant.length > 2 ? 480 : 580,
      }}>
      <View style={styles.innerPanel}>
        <Image
          source={{
            uri: item.product_image > [0] ? item.product_image[0].image : null,
          }}
          style={styles.Image}
          resizeMode="contain"
        />
        <View>
          <Text style={styles.headername}>{item.name}</Text>
          <Text numberOfLines={5} style={styles.description}>
            {item.description}
          </Text>
        </View>
      </View>
      <FlatList
        data={item.variant}
        keyExtractor={item => item.id}
        renderItem={RenderItem}
      />
    </View>
  );
};
export default BottomSheetInner;

const styles = StyleSheet.create({
  panel: {
    backgroundColor: colors.white,
  },
  innerPanel: {
    flexDirection: 'row',
    marginHorizontal: 20,
    // backgroundColor: colors.white,
  },
  Image: {
    height: 130,
    width: 100,
    marginTop: 10,
    marginLeft: 10,
    borderWidth: 1,
    borderColor: colors.lightgrey,
    borderRadius: 5,
  },
  bottomline: {
    borderBottomWidth: 2,
    borderBottomColor: colors.lightgrey,
    marginTop: 15,
  },
  cartCard2: {
    height: 100,
    borderRadius: 10,
    marginTop: 10,
    borderWidth: 1,
    borderColor: colors.lightgrey,
    marginHorizontal: 10,
    flexDirection: 'row',
  },
  headername: {
    marginTop: 10,
    marginLeft: 10,
    fontWeight: '500',
    textTransform: 'capitalize',
  },
  description: {
    marginTop: 10,
    marginLeft: 10,
    fontWeight: '500',
    width: 200,
    color: 'grey',
  },
  actionBtn: {
    width: 50,
    height: 30,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionBtn2: {
    width: 50,
    height: 30,
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  innerPrice: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.dark,
    marginTop: 10,
  },
  handle: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: 'lightgrey',
    width: SCREEN_WIDTH - 241,
    marginLeft: 160,
    marginHorizontal: 30,
    bottom: 45,
  },
  innerHeader: {
    marginHorizontal: 30,
    marginTop: 10,
  },
  nameText: {
    // flexDirection: "row",
    // justifyContent: "space-between",
    width: SCREEN_WIDTH - 80,
  },
});
