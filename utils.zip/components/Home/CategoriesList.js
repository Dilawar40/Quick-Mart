import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { colors } from '../../constants/GlobalStyles';
import { APIKit } from '../../utils/APIKIT';

const SCREEN_WIDTH = Dimensions.get('screen').width;
const BannerHeight = ((SCREEN_WIDTH - 40) * 198) / 335;

const CategoriesList = ({ data }) => {
  const navigation = useNavigation();

  const [productData, setProductData] = useState([]);

  const apiGetProduct = async selectedItem => {
    let id = await AsyncStorage.getItem('id');
    console.log('hghfhgg', id, selectedItem.id);
    var dataToSend = {
      user_id: id,
      category_id: selectedItem.id,
    };
    var url = 'v1/get-product-suplliers';
    let response = await APIKit.post(url, dataToSend)
      .then(function (response) {
        if (response) {
          // console.log('hELlooo', response.data)
          setTimeout(() => {
            navigation.navigate('SupplierListScreen1', {
              data: response.data,
            });
          }, 100);
        } else {
          console.log('responseError', response.data.message);
        }
      })
      .catch(function (error) {
        if (error.response.status === 401) {
          console.log('Token Expire goto login screen');
          navigation.navigate('LoginScreen');
        } else {
          console.log('Other error show it to user');
        }
      });
  };

  const imageBannerClicked = item => {
    console.log('item clicked', item);
    navigation.navigate('CartCard', {
      data: productData,
    });
  };

  const renderItem = ({ item }) => {
    console.log('bhhghhjhjh', item?.image);
    return (
      <View style={styles.container}>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => {
            apiGetProduct(item);
          }}>
          <Text style={styles.headerTitle}>{item.name}</Text>
          {/* <Text style={styles.headerTitle}>Hello</Text> */}
          <Image
            style={{ height: BannerHeight, width: SCREEN_WIDTH }}
            source={{ uri: item.image }}
            // source={require('../../Assets/coming001.png')}
            resizeMode="stretch"
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <View style={{ marginBottom: 10 }}>
        {/* <Text style={styles.headerTitle}>Categories</Text> */}
        <FlatList
          showsVerticalScrollIndicator={false}
          data={data}
          keyExtractor={item => item.id}
          renderItem={renderItem}
        />
      </View>
    </SafeAreaView>
  );
};

export default CategoriesList;

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: colors.white,
  },
  container: {
    backgroundColor: 'white',
  },
  headerTitle: {
    marginLeft: 15,
    fontWeight: '600',
    fontSize: 16,
    marginVertical: 10,
  },
});
