import {useNavigation} from '@react-navigation/native';
import React, {useEffect, useRef, useState, useCallback} from 'react';
import {
  Animated,
  BackHandler,
  Dimensions,
  FlatList,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {createShimmerPlaceholder} from 'react-native-shimmer-placeholder';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {colors, fonts} from '../../constants/GlobalStyles';
import Header from '../Header';
import BottomSheet from '@gorhom/bottom-sheet';
import BottomSheetInner from './BottomSheetInner';

const ShimmerPlaceHolder = createShimmerPlaceholder(LinearGradient);
const SCREEN_WIDTH = Dimensions.get('screen').width;

const CartCard = ({route}) => {
  const {data, onPress} = route.params;

  console.log('route', data.products);

  const [selectedItem, setSelectedItem] = useState([]);
  const [loader, setLoader] = useState(false);
  const [fall, setFall] = useState(null);

  const postRef = useRef(null);
  const bottomSheetRef = useRef(null);

  postRef.current = 1;
  // const [selectedItem2, setSelectedItem2] = useState(null);

  console.log('Hellooooo', postRef.current);
  const snapPoints = ['25%', '50%'];

  const navigation = useNavigation();
  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };
  useEffect(() => {
    BackHandler.addEventListener('hardwareBackPress', handleBackPress);

    return () =>
      BackHandler.removeEventListener('hardwareBackPress', handleBackPress);
  }, []);

  useEffect(() => {
    setFall(new Animated.Value(0));
  }, []);

  // callbacks
  const handleSheetChanges = useCallback(index => {
    console.log('handleSheetChanges', index);
  }, []);

  const openBottomSheet = () => {
    // Check if the expand method is available and call it
    if (bottomSheetRef.current && bottomSheetRef.current.expand) {
      bottomSheetRef.current.expand();
    }
  };

  const handleItemSelect = item => {
    // Save the selected item to state
    setSelectedItem(item);
    // Close the bottom sheet
    if (bottomSheetRef.current && bottomSheetRef.current.close) {
      bottomSheetRef.current.close();
    }
  };
  // const [productData, setProductData] = useState([]);
  // const [loading, setLoading] = useState(true);
  // const [page, setPage] = useState(1);
  // const [more, setMore] = useState(false);
  // const [totalPages, setTotalPages] = useState("");
  // const [pageLimit, setPageLimit] = useState(1);

  // useEffect(() => {
  //   apiGetProduct();
  // }, []);
  // const apiGetProduct = async () => {
  //   let id = await AsyncStorage.getItem("id");
  //   var dataToSend = {
  //     user_id: id,
  //   };
  //   console.log("dataToSend", dataToSend);
  //   var url = `v1/get-product?page_limit=25&page_no=${pageLimit}`;
  //   let response = await APIKit.post(url, dataToSend);
  //   if (response) {
  //     console.log("abcd", response.data);
  //     // setPageLimit(pageLimit + 1);
  //     setProductData([...productData, ...response.data.result]);
  //   } else {
  //     console.log("abcdError", response.data.message);
  //   }
  //   return response;
  // };

  // const loadMore = () => {
  //   setLoading(true);
  //   setPageLimit(pageLimit + 1);
  //   setTimeout(() => {
  //     setLoading(false);
  //   }, 800);
  // };
  // console.log("page", pageLimit);
  // const renderFooter = () => {
  //   return (
  //     <View style={styles.footer}>
  //       {loading ? (
  //         <ActivityIndicator color={colors.primary} size={25} />
  //       ) : null}
  //     </View>
  //   );
  // };

  const Header2 = () => {
    return (
      <View style={styles.header2}>
        <View style={styles.panelHeader}>
          <TouchableOpacity
            style={{
              bottom: 5,
            }}
            onPress={() => {
              postRef.current.snapTo(1);
            }}>
            <Icon name="clear" size={24} color={colors.dark} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  // let snapPoints =
  //   selectedItem.variant > [0] && selectedItem.variant.length > 0
  //     ? [300, 0] && selectedItem.variant.length > 1
  //       ? [510, 0] && selectedItem.variant.length > 2
  //         ? [520, 0] && selectedItem.variant.length > 3
  //           ? [720, 0]
  //           : [520, 0]
  //         : [410, 0]
  //       : [300, 0]
  //     : [300, 0];

  // const fall = new Animated.Value(0);

  const ProductList = ({item, index, onPress2}) => {
    // console.log('wwwwwwwwwwwwwww dksjdksjdk', item.variant[0].name)
    return (
      <View key={index} style={styles.container}>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={onPress2}
          style={styles.cartCard}>
          <Image
            source={{uri: item.product_image[0].image}}
            style={styles.Image}
            resizeMode="contain"
          />
          <View style={styles.rightBorder} />
          <View style={styles.mainHeader}>
            <Text
              style={{
                fontWeight: 'bold',
                fontSize: 16,
                textTransform: 'capitalize',
              }}>
              {item.name}
            </Text>
            {item.product_status === 'available' && (
              <TouchableOpacity
                activeOpacity={0.6}
                style={styles.inBox}
                onPress={() => {
                  postRef.current = 1;

                  setSelectedItem(item);
                  // onPress();
                }}>
                <Text style={styles.inText} numberOfLines={1}>
                  {item.variant[0].name}
                  {/* Nameee */}
                </Text>
                <View style={styles.dropdown}>
                  <Icon name="expand-more" size={15} color="white" />
                </View>
              </TouchableOpacity>
            )}
            {item.product_status === 'upcoming' && (
              <TouchableOpacity activeOpacity={0.6} style={styles.inBox}>
                <Text style={styles.inText} numberOfLines={1}>
                  {item.variant[0].name}
                </Text>
                <View style={styles.dropdown2}>
                  <Icon name="expand-more" size={15} color="white" />
                </View>
              </TouchableOpacity>
            )}
            {item.product_status === 'out_of_stock' && (
              <TouchableOpacity activeOpacity={0.6} style={styles.inBox}>
                <Text style={styles.inText} numberOfLines={1}>
                  {item.variant[0].name}
                </Text>
                <View style={styles.dropdown3}>
                  <Icon name="expand-more" size={15} color="white" />
                </View>
              </TouchableOpacity>
            )}
            <View style={styles.priceContainer}>
              <Text style={{fontSize: 14, fontWeight: '500'}}>
                £{item.variant[0].price}
              </Text>
              {item.product_status === 'available' && (
                <TouchableOpacity
                  activeOpacity={0.8}
                  style={styles.addContainer}
                  // onPress={() => {
                  // postRef.current.snapTo(0);
                  //   console.log(item);
                  //   setSelectedItem(item);
                  // }}
                  onPress={() => {
                    item.product_status != 'available'
                      ? null
                      : navigation.navigate('DetailsDemoScreen', {
                          data: item,
                        });
                    postRef.current = 0;
                  }}>
                  <Text style={{textAlign: 'center', color: colors.white}}>
                    Add to cart
                  </Text>
                </TouchableOpacity>
              )}
              {item.product_status === 'upcoming' && (
                <TouchableOpacity
                  activeOpacity={0.8}
                  style={styles.addContainer2}>
                  <Text style={{textAlign: 'center', color: colors.white}}>
                    UpComing
                  </Text>
                </TouchableOpacity>
              )}
              {item.product_status === 'out_of_stock' && (
                <TouchableOpacity
                  activeOpacity={0.8}
                  style={styles.addContainer3}>
                  <Text style={{textAlign: 'center', color: colors.white}}>
                    Out of Stock
                  </Text>
                </TouchableOpacity>
              )}
            </View>
            <Text style={{fontSize: 8, top: 10}}>
              {/* {item.variant[0].gst_price > 0
                ? '₹' + item.variant[0].gst_price
                : 'No'}{' '} */}
              {/* GST included */}
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };
  const RenderItem = ({item}) => {
    // console.log('check data ', item)
    return (
      <ProductList
        item={item}
        onPress2={() => {
          item.product_status != 'available'
            ? null
            : navigation.navigate('DetailsDemoScreen', {
                data: item,
              });
        }}
      />
    );
  };
  return (
    <SafeAreaView style={styles.mainContainer}>
      <Header
        title={'Products'}
        isNavigationRequired={true}
        color={'white'}
        backgroundColor={colors.mainHeader}
        height={50}
      />
      <Animated.View style={{flex: 1}}>
        {/* <Text style={styles.headerTitle}>Products</Text> */}
        {data.code === 201 ? (
          <View style={styles.NoDataContainer}>
            <Image
              source={require('../../Assets/history.jpg')}
              resizeMode="center"
              style={{height: '100%', width: '100%'}}
            />
            {/* <Text style={styles.NoDataText}>The product is not available</Text> */}
          </View>
        ) : null}

        <FlatList
          showsVerticalScrollIndicator={false}
          data={data.products}
          keyExtractor={item => item.id}
          renderItem={RenderItem}
          // ListFootz
          // erComponent={renderFooter}
          // onEndReached={loadMore}
          // onEndReachedThreshold={0.5}
        />
        {fall && (
          // <BottomSheet
          //   navigation={navigation}
          //   ref={postRef}
          //   // snapPoints={[400, 0]}
          //   snapPoints={snapPoints}
          //   renderContent={() => <BottomSheetInner item={selectedItem} />}
          //   renderHeader={Header2}
          //   initialSnap={1}
          //   callbackNode={fall}
          //   enabledGestureInteraction={true}
          // />
          <BottomSheet
            ref={bottomSheetRef}
            index={-1} // Set the initial index to hide the BottomSheet
            snapPoints={snapPoints}
            onChange={handleSheetChanges}>
            <BottomSheetInner item={selectedItem} />
          </BottomSheet>
        )}
        {/* <View>
          <Text>Hello</Text>
        </View> */}
      </Animated.View>
    </SafeAreaView>
  );
};

export default CartCard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // paddingVertical: 5,
    marginTop: 5,
  },
  mainContainer: {
    flex: 1,
    backgroundColor: colors.mainBackground,
  },
  cartCard: {
    // marginTop: 10,
    height: 130,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: '#f4f5f4',
    marginHorizontal: 10,
    flexDirection: 'row',
    marginBottom: 10,
    elevation: 10,
  },
  Image: {
    height: 120,
    width: 100,
    marginTop: 5,
    marginLeft: 2,
    borderColor: colors.lightgrey,
  },
  rightBorder: {
    borderRightWidth: 1,
    borderRightColor: colors.lightgrey,
    marginVertical: 5,
    marginLeft: 10,
  },
  mainHeader: {
    height: 100,
    width: SCREEN_WIDTH - (120 + 40),
    marginLeft: 10,
    marginTop: 10,
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    top: 20,
  },
  addContainer: {
    // marginTop: 30,
    // marginLeft: 100,
    borderWidth: 1,
    height: 30,
    width: 100,
    borderColor: colors.primary,
    borderRadius: 5,
    justifyContent: 'center',
    backgroundColor: colors.primary,
  },
  addContainer2: {
    // marginTop: 30,
    // marginLeft: 100,
    borderWidth: 1,
    height: 30,
    width: 100,
    borderColor: '#5D2DE3',
    borderRadius: 5,
    justifyContent: 'center',
    backgroundColor: '#5D2DE3',
  },
  addContainer3: {
    // marginTop: 30,
    // marginLeft: 100,
    borderWidth: 1,
    height: 30,
    width: 100,
    borderColor: '#FA3E3E',
    borderRadius: 5,
    justifyContent: 'center',
    backgroundColor: '#FA3E3E',
  },
  headerTitle: {
    marginLeft: 20,
    fontWeight: '600',
    fontSize: 16,
    marginBottom: 10,
  },
  dropdown: {
    height: 15,
    width: 15,
    backgroundColor: colors.primary,
    borderRadius: 10,
    right: 5,
  },
  dropdown2: {
    height: 15,
    width: 15,
    backgroundColor: '#5D2DE3',
    borderRadius: 10,
    right: 5,
  },
  dropdown3: {
    height: 15,
    width: 15,
    backgroundColor: '#FA3E3E',
    borderRadius: 10,
    right: 5,
  },
  inBox: {
    height: 30,
    width: SCREEN_WIDTH - 1000,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    borderColor: colors.grey,
    top: 10,
    flexDirection: 'row',
  },
  inText: {
    left: 5,
    width: 150,
    textTransform: 'uppercase',
  },
  header2: {
    backgroundColor: '#fff',
    paddingTop: 15,
    borderTopColor: colors.lightgrey,
    borderTopWidth: 1,
  },
  panelHeader: {
    alignItems: 'flex-end',
    marginHorizontal: 10,
  },
  footer: {
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  btnText: {
    color: 'black',
    fontSize: 15,
    textAlign: 'center',
  },
  NoDataContainer: {
    // flex: 1,
    // flexDirection: "column",
    justifyContent: 'space-around',
    alignItems: 'center',
    marginTop: 50,
    marginHorizontal: 20,
  },
  NoDataText: {
    fontSize: 18,
    fontFamily: fonts.headerFont,
    color: colors.primary,
    marginBottom: 160,
  },
});
