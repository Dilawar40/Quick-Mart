import React from "react";
import { StyleSheet, TouchableOpacity, View, Text } from "react-native";
import { colors, fonts } from "../constants/GlobalStyles";

const PrimaryButton = ({ title, onPress = () => {} }) => {
  return (
    <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
      <View style={style.btnContainer}>
        <Text style={style.title}>{title}</Text>
      </View>
    </TouchableOpacity>
  );
};
const SecondaryButton = ({ title, onPress = () => {} }) => {
  return (
    <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
      <View
        style={{ ...style.btnContainer, backgroundColor: colors.lightgrey }}
      >
        <Text style={{ ...style.title, color: colors.grey }}>{title}</Text>
      </View>
    </TouchableOpacity>
  );
};

const style = StyleSheet.create({
  title: {
    color: colors.white,
    // fontWeight: "700",
    fontSize: 18,
    fontFamily: fonts.headerFont,
  },
  btnContainer: {
    backgroundColor: colors.primary,
    height: 40,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10,
  },
});

export { PrimaryButton, SecondaryButton };
