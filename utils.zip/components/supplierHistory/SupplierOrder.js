import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import {
  FlatList,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { createShimmerPlaceholder } from 'react-native-shimmer-placeholder';
import { apiGetSupplierOrders } from '../../utils/APIKIT';
const ShimmerPlaceHolder = createShimmerPlaceholder(LinearGradient);

const SupplierOrder = () => {
  const [supplierOrder, setSupplierOrders] = useState([]);
  const [loader, setLoader] = useState(false);

  setTimeout(() => {
    setLoader(true)
  }, 1000);

  const navigation = useNavigation()

  const data = [
    {
      key: '1',
      title: 'vigetable Name',
      title1: 'Variant: Vegetable Name',
      quantity: ' 3',
      total: ' $48',
      button: 'Update',
    },
    {
      key: '2',
      title: 'vigetable Name',
      title1: 'Variant: Vegetable Name',
      quantity: ' 3',
      total: ' $48',
      button: 'Update',
    },
    {
      key: '3',
      title: 'vigetable Name',
      title1: 'Variant: Vegetable Name',
      quantity: ' 3',
      total: ' $48',
      button: 'Update',
    },

    // Add more items as needed
  ];

  const FetchSupplierOrders = async () => {
    let response = await apiGetSupplierOrders()
      .then(function (response) {
        // console.log(response);
        if (response) {
          setLoader(true);
          // console.log('SupplierOrders -------------------', response.data.result);
          setSupplierOrders(response.data.result);
        } else {
          console.log('responseError', response.data.message);
        }
      })
      .catch(function (error) {
        // handle error
        if (error.response.status === 401) {
          console.log('Token Expire goto login screen');
          navigation.navigate('LoginScreen');
        } else {
          console.log('Other error show it to user');
        }
      });
  };

  useEffect(() => {
    // apiGetSupplierOrders();
    FetchSupplierOrders();
  }, []);

  // console.log('Hellooooooooooooooooooooo 111111111111111111', supplierOrder);

  const renderview = ({ item }) => {
    // console.log(
    //   'Gellllllllllllll ----------',
    //   item
    // );
    return (
      <TouchableOpacity onPress={() => navigation.navigate('OrderDetailScreen', { item2: item })}
        style={{
          alignSelf: 'center',
          borderWidth: 1,
          marginVertical: '2%',
          borderRadius: 10,
          borderColor: '#DFD9D9',
          height: 90,
          width: '95%',
          backgroundColor: '#F8F6F4',
          justifyContent: 'center',
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginHorizontal: '3%',
            marginTop: 5,
          }}>
          <View>
            <TouchableOpacity>
              <Image
                source={require('../../Assets/camera.png')}
                style={{ height: 58, width: 58, marginRight: '3%' }}
              />
            </TouchableOpacity>
          </View>
          <View style={{ flexDirection: 'column', marginTop: '3%' }}>
            <Text style={{ color: 'black', marginBottom: 7 }}>
              Variant {item.order_details?.[0].gst_price}
            </Text>
            <View style={{ flexDirection: "row", justifyContent: 'center', alignItems: "center" }}>
              <Text style={{}}>Status </Text>
              <Text style={{ color: 'black', fontSize: 14 }}>{item.status}</Text>
            </View>
          </View>
          <View style={{}}>
            <View style={{ flexDirection: 'column' }}>
              <Text
                style={{
                  color: 'black',
                  alignSelf: 'flex-end',
                  marginBottom: 3,
                }}>
                Qty:{item.order_details[0].product_qty}
              </Text>
              <Text style={{ color: 'black', marginBottom: 3 }}>
                Total:{item.order_details?.[0].total_price}
              </Text>
            </View>
            <TouchableOpacity>
              <View
                style={{
                  alignItems: 'center',
                  backgroundColor: 'rgba(249, 184, 22, 1)',
                  borderRadius: 5,
                  height: 23,
                  width: '100%',
                }}>
                <Text style={{ borderRadius: 3, color: 'black' }}>Detail</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={{ backgroundColor: 'white', flex: 1 }}>
      <ScrollView>
        {
          loader ?
            (<FlatList
              data={supplierOrder}
              contentContainerStyle={{ flex: 1 }}
              renderItem={renderview}
              keyExtractor={item => item.key}
            />) :
            (
              <FlatList
                data={[1, 1, 1, 1, 1, 1, 1, 1, 1]}
                renderItem={({ item }) => {
                  return (
                    <View
                      style={{
                        width: "100%",
                        height: 170,
                        borderRadius: 20,
                        marginTop: 15,
                      }}
                    >
                      <ShimmerPlaceHolder
                        shimmerColors={["#ebebeb", "#DBDBDB", "#ebebeb"]}
                        style={{
                          width: 150,
                          borderRadius: 20,
                          marginTop: 10,
                          marginHorizontal: 10,
                        }}
                      />
                      <ShimmerPlaceHolder
                        shimmerColors={["#ebebeb", "#DBDBDB", "#ebebeb"]}
                        style={{
                          width: "95%",
                          height: 150,
                          borderRadius: 20,
                          marginTop: 10,
                          marginHorizontal: 10,
                        }}
                      ></ShimmerPlaceHolder>
                    </View>
                  );
                }}
              />
            )
        }
        {/* <Text style={{alignSelf: 'flex-end', marginBottom: '60%'}}>
        Total Amount: $126
      </Text> */}
      </ScrollView>
    </View>
  );
};

export default SupplierOrder;

const styles = StyleSheet.create({});
