import { SCREEN_HEIGHT, SCREEN_WIDTH } from "@gorhom/bottom-sheet";
import { StyleSheet } from "react-native";
import { colors } from "../../constants/GlobalStyles";

const styles = StyleSheet.create({
  carousalDotStyle: {
    // position: "absolute",
    bottom: 0,
    flexDirection: "row",
    alignSelf: "center",
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 5,
    backgroundColor: colors.primary,
    top: 20,
    // marginBottom: -50,
  },
  customStyle: {
    flexGrow: 0,
    marginBottom: -70,
  },
  inactiveDotStyle: {
    backgroundColor: colors.primary,
  },
});
export default styles;
