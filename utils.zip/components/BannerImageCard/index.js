import React, { useState } from "react";
import { Dimensions, Image, TouchableOpacity, View } from "react-native";
import Carousel, { Pagination } from "react-native-snap-carousel";
import styles from "./styles";
// import { openLinkInCustomTab } from 'Common/utils';

const SCREEN_WIDTH = Dimensions.get("screen").width;
const BannerHeight = ((SCREEN_WIDTH - 40) * 198) / 335;

const BannerImageCard = ({ data }) => {
  const [activeSlide, setActiveSlide] = useState(0);

  const imageBannerClicked = (item) => {
    console.log("item clicked", item);
    // openLinkInCustomTab(item.bannerLink)
  };

  const renderItem = ({ item }) => {
    return (
      <View
        style={{
          width: "100%",
          height: BannerHeight,
          backgroundColor: "white",
          marginTop: 5,
          // marginHorizontal: 20,
        }}
      >
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => {
            imageBannerClicked(item);
          }}
        >
          <Image
            style={{ height: BannerHeight }}
            source={{ uri: item.image }}
          />
        </TouchableOpacity>
      </View>
    );
  };

  const pagination = () => {
    return (
      <Pagination
        dotsLength={data ? data.length : null}
        activeDotIndex={activeSlide}
        dotStyle={styles.carousalDotStyle}
        inactiveDotOpacity={0.6}
        inactiveDotScale={0.6}
      // inactiveDotStyle={styles.inactiveDotStyle}
      />
    );
  };

  return (
    <>
      <Carousel
        data={data}
        vertical={false}
        autoplay={true}
        renderItem={renderItem}
        onSnapToItem={(index) => setActiveSlide(index)}
        sliderWidth={SCREEN_WIDTH}
        itemWidth={SCREEN_WIDTH * 1}
        containerCustomStyle={styles.customStyle}
      />
      {pagination()}
    </>
  );
};

export default BannerImageCard;
