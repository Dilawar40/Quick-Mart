import React, { useEffect } from 'react';
import { BackHandler, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';


import { colors } from '../../constants/GlobalStyles';
const { Dimensions } = require('react-native');


const SCREEN_WIDTH = Dimensions.get('screen').width;

const BalaceSection = ({ navigation,profileData }) => {
    const balance = "$10,000.00"; // Replace with your actual balance data
    const userName = "John Doe";  // Replace with your actual user name data

    console.log('check the data setting ',profileData)

    const handleBackPress = () => {
        navigation.goBack();
        return true;
    };
    useEffect(() => {
        BackHandler.addEventListener("hardwareBackPress", handleBackPress);

        return () =>
            BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    }, []);


    return (
        <View style={styles.container}>
            {/* <View style={styles.balanceContainer}>
                <Text style={styles.balanceText}>{balance}</Text>
            </View>
            <View style={styles.userNameContainer}>
                <Text style={styles.userNameText}>Hello, {userName}!</Text>
            </View> */}
            <View style={styles.innerContainer}>
                <TouchableOpacity
                    activeOpacity={0.8}
                    style={styles.mainContainer2}
                // onPress={onPress}
                >
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                        {/* <Image
                            style={styles.image}
                            source={
                                // item.image
                                    // ? { uri: item.image }
                                    // :
                                     require('../../Assets/logo.png')
                            }
                            resizeMode="contain"
                        /> */}
                        <View style={styles.nameText}>
                            <View style={styles.header}>
                                <Text style={styles.customerName}>
                                    {/* {item.name} */}
                                    Balance
                                </Text>
                            </View>
                            <View
                                style={{
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                    alignItems: 'center',
                                }}>
                                <Text style={styles.customerNamemoney}>
                                    {/* order status:{" "} */}
                                    £{profileData.wallet_amount}
                                    {/* : {item.mobile} */}
                                </Text>
                            </View>
                            <Text style={styles.date}>
                                Your total balance is £{profileData.wallet_amount}, providing a comprehensive overview of your financial status.
                            </Text>
                        </View>
                    </View>
                    <View>
                        <Image source={require('../../Assets/moneyBag.png')} style={{width:50,height:70,top:60}}/>
                    </View>
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        // justifyContent: 'center',
        // alignItems: 'center',
        backgroundColor: '#f0f0f0',
    },
    balanceContainer: {
        marginBottom: 20,
    },
    balanceText: {
        fontSize: 36,
        fontWeight: 'bold',
        color: '#333',
    },
    userNameContainer: {
        marginTop: 20,
    },
    userNameText: {
        fontSize: 20,
        color: '#555',
    },
    innerContainer: {
        // marginTop: 10,
        // marginBottom: 10,
        marginTop: 30
    },
    mainContainer: {
        flex: 1,
        marginTop: 30
    },
    mainContainer2: {
        height: 200,
        // width: "100%",
        borderWidth: 1,
        backgroundColor: colors.white,
        borderRadius: 20,
        marginHorizontal: 10,
        borderColor: '#f4f5f4',
        elevation: 10,
        flexDirection:'row'
    },
    image: {
        height: 60,
        width: 60,
        marginTop: 9,
        marginHorizontal: 10,
        borderRadius: 5,
    },
    nameText: {
        // flex: 1,
        marginTop: 20,
        marginHorizontal: 20,
        width: SCREEN_WIDTH - 140,
    },
    mainHeader: {
        height: 100,
        width: SCREEN_WIDTH - (120 + 40),
        marginLeft: 10,
        marginTop: 10,
    },
    customerName: {
        fontSize: 22,
        fontWeight: '600',
        color: colors.darkOrange,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    customerOtp: {
        fontSize: 12,
        fontWeight: '600',
        color: colors.grey,
        marginTop: 2,
        textTransform: 'uppercase',
        fontWeight: 'bold',
    },
    customerNamemoney: {
        fontSize: 35,
        fontWeight: '600',
        color: 'black',
        marginTop: 5,
        textTransform: 'capitalize',
        fontWeight: 'bold',
    },
    date: {
        color: colors.darkOrange,
        fontSize: 12,
        marginTop: 5,
    },
    price: {
        color: colors.darkOrange,
        fontWeight: '700',
    },
});

export default BalaceSection;