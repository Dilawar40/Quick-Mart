import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import {
    BackHandler,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from "react-native";
import Toast from "react-native-toast-message";
import Header from "../../components/Header";
import PrimaryInputForm from "../../components/PrimaryInputForm";
import { colors } from "../../constants/GlobalStyles";
import { APIKit } from "../../utils/APIKIT";

const EditProfile = ({ route }) => {
  const { profileData } = route.params;

  console.log("===========", profileData);
  const navigation = useNavigation();
  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };
  useEffect(() => {
    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () =>
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
  }, []);

  const ErrorMessage = (item) => {
    Toast.show({
      type: "error",
      text1: "Error",
      text2: item,
      topOffset: 80,
    });
  };

  const [userName, setUserName] = useState(profileData.name);
  const [userPhoneNumber, setUserPhoneNumber] = useState(profileData.mobile);
  const [userAddress, setUserAddress] = useState(profileData.address);

  const handleSubmitButton = async () => {
    let id = await AsyncStorage.getItem("id");
    var dataToSend = {
      id: id,
      name: userName,
      mobile: userPhoneNumber,
      address: userAddress,
    };
    console.log("dataToSend", dataToSend);

    APIKit.post("v1/update-profile", dataToSend)

      .then((response) => {
        console.log("update-profile", response.data);
        if (response.data.code === 200) {
          navigation.navigate("Profile");
        } else {
          ErrorMessage(response.data.message);
          console.log("status", response.data);
        }
      })
      .catch((error) => {
        console.log("error221", error);
      });
  };

  return (
    <View style={styles.container}>
      <Header
        title={"Edit Profile"}
        isNavigationRequired={true}
        color={"white"}
        backgroundColor={colors.mainHeader}
        height={50}
      />
      <ScrollView
        style={styles.sectionMiddle}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.inputItem}>
          <Text style={styles.inputTitle}>Name</Text>
          <PrimaryInputForm
            placeHolderText={"Type name..."}
            value={userName}
            onChangeText={setUserName}
          />
        </View>
        <View style={styles.inputItem}>
          <Text style={styles.inputTitle}>Phone Number</Text>
          <PrimaryInputForm
            placeHolderText={"Type number..."}
            value={userPhoneNumber}
            onChangeText={setUserPhoneNumber}
            keyboardType="numeric"
          />
        </View>
        <View>
          <Text style={styles.inputTitle}>Address</Text>
          <TextInput
            style={styles.inputAddress}
            placeholder="Type address..."
            value={userAddress}
            multiline={true}
            onChangeText={setUserAddress}
          />
        </View>
      </ScrollView>
      <View style={styles.inputItem}>
        <TouchableOpacity
          activeOpacity={0.8}
          style={styles.button}
          onPress={() => handleSubmitButton()}
        >
          <Text style={styles.save}>Submit</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default EditProfile;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.mainBackground,
  },
  sectionMiddle: {
    flex: 1,
    marginTop: 15,
    marginHorizontal: 20,
  },
  inputItem: {
    marginBottom: 5,
  },
  title: {
    fontSize: 30,
    fontWeight: "600",
  },
  inputTitle: {
    color: colors.darkOrange,
    fontSize: 16,
    fontFamily: "Lexend-Medium",
    marginBottom: 5,
  },
  inputAddress: {
    borderWidth: 0.5,
    borderColor: "gray",
    borderRadius: 10,
    height: 100,
    // width: "100%",
    paddingLeft: 5,
    backgroundColor: "#fff",
  },
  button: {
    backgroundColor: colors.mainButton,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
    marginHorizontal: 20,
    // top: 50,
  },
  save: {
    fontSize: 16,
    fontWeight: "500",
    lineHeight: 20,
    color: "#FFFFFF",
  },
});
