import React from "react";
import { StyleSheet, Text, View } from "react-native";
import Icon from "react-native-vector-icons/FontAwesome5";
import { colors, fonts } from "../../constants/GlobalStyles";


const ProfileSection = ({ profileData }) => {
  return (
    <View style={styles.container}>
      <View style={styles.mainHeader}>
        <View style={styles.inBox}>
          <Icon name="user" size={18} style={{ left: 10 }} />
          <Text style={styles.innerText}>Name :</Text>
          <Text style={styles.innerText2} numberOfLines={2}>
            {" "}
            {profileData.name}
          </Text>
        </View>
        <View style={styles.inBox}>
          <Icon name="phone-volume" size={18} style={{ left: 10 }} />
          <Text style={styles.innerText}>Mobile :</Text>
          <Text style={styles.innerText2}> {profileData.mobile}</Text>
        </View>
        <View style={styles.inBox2}>
          <Icon name="address-card" size={18} style={{ left: 10 }} />
          <Text style={styles.innerText}>Address :</Text>
          <Text style={styles.innerText2} numberOfLines={4}>
            {" "}
            {profileData.address}
          </Text>
        </View>
      </View>
    </View>
  );
};

export default ProfileSection;

const styles = StyleSheet.create({
  container: {
    marginTop: 10,
  },
  mainHeader: {
    marginHorizontal: 20,
    marginTop: 10,
  },
  inBox: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.lightgrey,
    borderRadius: 10,
    height: 60,
    marginBottom: 20,
    backgroundColor: colors.white,
    elevation: 10,
  },
  innerText: {
    fontFamily: fonts.headerFont,
    left: 20,
    fontSize: 16,
  },
  innerText2: {
    fontFamily: fonts.headerFont,
    left: 30,
    fontSize: 16,
    color: colors.grey,
    width: 180,
    textTransform: "capitalize",
  },
  inBox2: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.lightgrey,
    borderRadius: 10,
    height: 100,
    marginBottom: 20,
    backgroundColor: colors.white,
    elevation: 10,
  },
});
