import { StyleSheet, Text, View, Dimensions } from "react-native";
import React from "react";
import { colors, fonts } from "../../constants/GlobalStyles";
import Icon from "react-native-vector-icons/Ionicons";
import moment from "moment";

const width = Dimensions.get("screen").width;
const PackageSection = ({ profileData }) => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.wallet} adjustsFontSizeToFit>
          Package
        </Text>
        <View style={styles.walletBox}>
          <View style={styles.innerView}>
            <Icon name="calendar" size={18} />
            <Text style={styles.innerText} adjustsFontSizeToFit>
              Start Date :
            </Text>
            <Text style={styles.innerText2} adjustsFontSizeToFit={true}>
              {moment(profileData.package_start_date).format("DD-MM-YYYY")}
            </Text>
          </View>
          <View style={styles.innerView}>
            <Icon name="calendar-outline" size={18} />
            <Text style={styles.innerText} adjustsFontSizeToFit>
              End Date{"  "} :
            </Text>
            <Text style={styles.innerText3} adjustsFontSizeToFit={true}>
              {moment(profileData.expiry_date).format("DD-MM-YYYY")}
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
};

export default PackageSection;

const styles = StyleSheet.create({
  container: {
    marginTop: 10,
  },
  header: {
    marginHorizontal: 20,
  },
  wallet: {
    fontSize: 16,
    fontWeight: "600",
  },
  walletBox: {
    borderWidth: 1,
    height: 80,
    borderRadius: 10,
    marginTop: 10,
    borderColor: colors.lightgrey,
    backgroundColor: colors.white,
    elevation: 10,
  },
  innerView: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 10,
    marginTop: 10,
  },
  innerText: {
    fontFamily: fonts.headerFont,
    left: 10,
    fontSize: 16,
  },
  innerText2: {
    fontFamily: fonts.headerFont,
    left: 30,
    fontSize: 16,
    // width: 150,
    color: colors.darkOrange,
  },
  innerText3: {
    fontFamily: fonts.headerFont,
    left: 30,
    fontSize: 16,
    // width: 150,
    color: "#cc3333",
  },
});
