import moment from "moment";
import React, { useEffect, useState } from "react";
import { BackHandler, Dimensions, FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { createShimmerPlaceholder } from "react-native-shimmer-placeholder";
import { colors, fonts } from "../../constants/GlobalStyles";
import { apiGetTransactions } from "../../utils/APIKIT";
import Header from "../Header";

const SCREEN_WIDTH = Dimensions.get("screen").width;
const ShimmerPlaceHolder = createShimmerPlaceholder(LinearGradient);

const ViewTransactions = ({ navigation }) => {
  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };
  useEffect(() => {
    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () =>
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
  }, []);

  useEffect(() => {
    setTimeout(() => {
      FetchTransaction();
    }, 100);
  }, []);

  const [transactions, setTransactions] = useState();
  const [loader, setLoader] = useState(false);

  const FetchTransaction = async () => {
    let response = await apiGetTransactions()
      .then(function (response) {
        if (response) {
          setLoader(true);
          console.log("responseTransaction", response.data);
          setTransactions(response.data.result);
        } else {
          console.log("responseTransactionError", response.data.message);
        }
      })
      .catch(function (error) {
        if (error.response.status === 401) {
          console.log("Token Expire goto login screen");
          navigation.navigate("LoginScreen");
        } else {
          console.log("Other error show it to user");
        }
      });
  };

  const renderItem = ({ item }) => {
    return (
      <View style={styles.innerContainer}>
        <TouchableOpacity activeOpacity={0.8} style={styles.mainContainer2}>
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={styles.nameText}>
              <Text style={styles.customerName} numberOfLines={1}>
                Trans_no : {item.transaction_no}
              </Text>
              <View style={styles.middleline}>
                <View
                  style={{
                    flexDirection: "row",
                  }}
                ></View>
                <View>
                  <Text style={styles.price}>
                    {"\u00A3"}
                    {item.amount}
                  </Text>
                </View>
              </View>
              <View style={{ flexDirection: "row" }}>
                <Text style={styles.date}>
                  {moment(item.created_at).format("DD-MM-YYYY")}
                </Text>
                <Text style={styles.time}>
                  {moment(item.created_at).format("hh:mm A")}
                </Text>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.mainContainer}>
        <Header
          title={"History"}
          isNavigationRequired={true}
          color={"white"}
          backgroundColor={colors.mainHeader}
          height={50}
        />
        {loader ? (
          <FlatList
            showsVerticalScrollIndicator={false}
            data={transactions}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
          />
        ) : (
          <FlatList
            data={[1, 1, 1, 1, 1, 1, 1, 1, 1]}
            renderItem={({ item }) => {
              return (
                <View
                  style={{
                    width: "100%",
                    // height: 170,
                    borderRadius: 20,
                    marginTop: 10,
                  }}
                >
                  <ShimmerPlaceHolder
                    shimmerColors={["#ebebeb", "#DBDBDB", "#ebebeb"]}
                    style={{
                      width: "95%",
                      height: 80,
                      borderRadius: 20,
                      marginTop: 10,
                      marginHorizontal: 10,
                    }}
                  />
                </View>
              );
            }}
          />
        )}
        {loader && transactions === undefined ? (
          <View style={styles.NoDataContainer}>
            <Image
              source={require("../../Assets/transaction.jpg")}
              resizeMode="center"
              style={{ height: "100%", width: "100%" }}
            />
            <Text style={styles.NoDataText}>
              You have no Transactions history.
            </Text>
          </View>
        ) : null}
      </View>
    </View>
  );
};

export default ViewTransactions;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.mainBackground,
  },
  innerContainer: {
    marginTop: 10,
  },
  mainContainer: {
    flex: 1,
  },
  mainContainer2: {
    height: 80,
    borderWidth: 1,
    backgroundColor: colors.white,
    borderRadius: 20,
    marginBottom: 5,
    marginHorizontal: 10,
    borderColor: "#f4f5f4",
    elevation: 10,
  },
  nameText: {
    marginTop: 5,
    marginHorizontal: 10,
    width: SCREEN_WIDTH - 120,
  },
  customerName: {
    fontSize: 16,
    fontWeight: "600",
    color: colors.darkOrange,
  },
  middleline: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  date: {
    color: colors.darkOrange,
    fontSize: 12,
    marginTop: 5,
  },
  time: {
    color: colors.darkOrange,
    fontSize: 12,
    marginTop: 5,
    marginLeft: 10,
  },
  price: {
    color: colors.primary,
    fontWeight: "700",
    fontSize: 16,
    left: 50,
  },
  NoDataContainer: {
    justifyContent: "space-around",
    alignItems: "center",
    marginTop: 50,
    marginHorizontal: 20,
  },
  NoDataText: {
    fontSize: 18,
    marginBottom: 200,
    color: colors.primary,
    fontFamily: fonts.headerFont,
  },
});
