import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import { colors, fonts } from '../../constants/GlobalStyles';
import { apiGetProfile } from '../../utils/APIKIT';
import Header from '../Header';
import BalaceSection from './BalanceSection';


const WalletSection = () => {


  const [loader,setLoader] = useState([])
  console.log('Check the profile Data ', profileData);
  const [profileData, setProfileData] = useState([]);
  const value2 = AsyncStorage.getItem('is_supplier');
  const FetchProfile = async () => {
    let response = await apiGetProfile()
      .then(function (response) {
        // console.log(response);
        if (response) {
          setLoader(true);
          console.log('responseGetProfile', response.data);
          setProfileData(response.data.result);
        } else {
          console.log('responseProfileError', response.data.message);
        }
      })
      .catch(function (error) {
        // handle error
        if (error.response.status === 401) {
          console.log('Token Expire goto login screen');
          navigation.navigate('LoginScreen');
        } else {
          console.log('Other error show it to user');
        }
      });
  };
  const navigation = useNavigation();

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      FetchProfile();
    });
    return () => {
      unsubscribe;
    };
  }, []);

  return (
    <View style={styles.container}>
      <Header
        title={"Account"}
        isNavigationRequired={true}
        color={"white"}
        backgroundColor={colors.mainHeader}
        height={50}
        left={5}
      />
      <View style={styles.header}>
        <Text style={styles.wallet}>Balance</Text>
        <View style={styles.walletBox}>
          <View style={styles.innerView}>
            <Icon name="wallet" size={18} />
            <Text style={styles.innerText}>Balance :</Text>
            <Text style={styles.innerText2}>{profileData.wallet_amount}</Text>
          </View>
          <View style={styles.middleContainer}>
            {

              value2 === '1' ? <TouchableOpacity
                activeOpacity={0.6}
                style={styles.buttonContainer}
                onPress={() => {
                  navigation.navigate('AddtoWallet', {
                    profileData: profileData,
                  });
                }}>
                <Text style={styles.buttonText}>Add Balance</Text>
              </TouchableOpacity> : null

            }

            <TouchableOpacity
              activeOpacity={0.6}
              style={styles.viewTransactions}
              onPress={() => {
                navigation.navigate('ViewTransactions');
              }}>
              <Text style={styles.buttonText}>View Transactions</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    <BalaceSection profileData={profileData}/>
    </View>
  );
};

export default WalletSection;

const styles = StyleSheet.create({
  container: {
    // marginTop: 10,
  },
  header: {
    marginHorizontal: 20,
  },
  wallet: {
    fontSize: 16,
    fontWeight: '600',
  },
  walletBox: {
    borderWidth: 1,
    height: 90,
    borderRadius: 10,
    marginTop: 10,
    borderColor: colors.lightgrey,
    backgroundColor: colors.white,
    elevation: 10,
  },
  innerView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 10,
    marginTop: 10,
  },
  middleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 10,
    marginTop: 10,
  },
  buttonContainer: {
    borderRadius: 5,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    width: '40%',
    height: 30,
    marginTop: 5,
  },
  viewTransactions: {
    borderRadius: 5,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    width: '50%',
    height: 30,
    marginTop: 5,
  },
  buttonText: {
    fontFamily: fonts.headerFont,
    fontSize: 16,
    color: colors.white,
  },
  innerText: {
    fontFamily: fonts.headerFont,
    fontSize: 16,
    left: 10,
  },
  innerText2: {
    fontFamily: fonts.headerFont,
    left: 30,
    fontSize: 16,
    width: 150,
    color: colors.darkOrange,
  },
});
