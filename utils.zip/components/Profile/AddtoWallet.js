import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useEffect, useState } from "react";
import {
  Alert,
  BackHandler,
  FlatList,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import RazorpayCheckout from "react-native-razorpay";
import Toast from "react-native-toast-message";
import Icon from "react-native-vector-icons/FontAwesome5";
import { RazorpayKey } from "../../Config";
import { colors, fonts } from "../../constants/GlobalStyles";
import { APIKit } from "../../utils/APIKIT";
import { logo, orders } from "../../utils/data";
import Header from "../Header";

const AddtoWallet = ({ navigation, route }) => {
  const { profileData } = route.params;
  // console.log("profileData", profileData);
  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };

  useEffect(() => {
    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () =>
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
  }, []);

  const WarningAlert = (item) =>
    Alert.alert(
      "Warning",
      item,
      [
        {
          text: "OK",
          onPress: () => console.log("OK Pressed"),
        },
      ],
      {
        cancelable: true,
      }
    );

  const TostMessage = (item) => {
    Toast.show({
      type: "success",
      text1: "Success",
      text2: item,
      topOffset: 80,
    });
  };
  const ErrorMessage = (item) => {
    Toast.show({
      type: "error",
      text1: "Error",
      text2: item,
      topOffset: 80,
    });
  };
  const AddTransaction = async (item) => {
    let id = await AsyncStorage.getItem("id");
    var dataToSend = {
      user_id: id,
      amount: selected,
      transaction_no: item,
    };
    console.log("dataToSend", dataToSend);
    APIKit.post("v1/add-transaction", dataToSend)
      .then((response) => {
        console.log("add-transaction", response.data);
        TostMessage(response.data.message);
        navigation.navigate("Profile");
      })
      .catch((error) => {
        ErrorMessage(response.data.message);
        console.log("error222", error);
      });
  };

  const razorPay = () => {
    var options = {
      description: "Credits towards consultation",
      image: logo,
      currency: "INR",
      key: RazorpayKey.key,
      amount: selected ? selected * 100 : null,
      name: "APSE",
      order_id: "", //Replace this with an order_id created using Orders API.
      prefill: {
        // email: "sanjay.kumar@gmail.com",
        contact: profileData.mobile,
        name: profileData.name,
      },
      theme: { color: colors.primary },
    };
    RazorpayCheckout.open(options)
      .then((data) => {
        // handle success
        // alert(`Success: ${data.razorpay_payment_id}`);
        AddTransaction(data.razorpay_payment_id);
        // WarningAlert(data.razorpay_payment_id);
        // navigation.navigate("Profile");
      })
      .catch((error) => {
        // handle failure
        WarningAlert(error.description);
        // console.log(error.description);
        // alert(`Error: ${error.code} | ${error.description}`);
      });
  };
  const handleChange = (text) => {
    const strNumber = text
      .replace(/[^0-9]/g, "")
      .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    setSelected(strNumber);
  };

  const [selected, setSelected] = useState();
  const [status, setStatus] = useState("");
  const [warning, setWarning] = useState(false);

  console.log("Selected", selected);
  const setStatusFilter = (status) => {
    setStatus(status);
  };
  const RenderItem = ({ item, index }) => {
    return (
      <View key={index} style={{}}>
        <View style={styles.buttonsContainer}>
          <View style={styles.buttonsRowView}>
            <TouchableOpacity
              style={
                item === status
                  ? styles.pressedButtonRipple
                  : styles.buttonRipple
              }
              onPress={() => {
                // setStatusFilter(item);
                setSelected(item.price);
              }}
            >
              <View style={styles.rippleView}>
                <Text
                  style={
                    item === status
                      ? styles.pressedButtontitle
                      : styles.buttontitle
                  }
                >
                  {"£" + item.price}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Header
        title={"Add Wallet"}
        isNavigationRequired={true}
        color={"white"}
        backgroundColor={colors.mainHeader}
        height={50}
      />
      {/* first Section */}
      <View style={styles.header}>
        <View style={styles.walletBox}>
          <Text style={styles.innerText}>Balance</Text>
          <View style={styles.innerView}>
            <Text style={styles.innerText2}> {profileData.wallet_amount}</Text>
            <Icon name="wallet" size={26} style={{ bottom: 15 }} />
          </View>
        </View>
      </View>
      {/* Second Section */}
      <View style={styles.header}>
        <View style={styles.walletContainer}>
          <Text style={styles.innerText}>Add Money to Balance</Text>

          <View style={styles.textInput}>
            <TextInput
              style={{ marginLeft: 5 }}
              placeholder="£ Amount"
              value={selected}
              onChangeText={(text) => setSelected(text)}
              keyboardType={"decimal-pad"}
            // maxLength={5}
            />
          </View>
          {warning ? (
            <Text style={styles.warning}>You can add only upto £ 99,999</Text>
          ) : null}
          <FlatList
            horizontal
            showsHorizontalScrollIndicator={false}
            data={orders}
            keyExtractor={(item) => item.id}
            renderItem={RenderItem}
          />
        </View>
        <View style={styles.header}>
          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.button}
            onPress={() => {
              selected > 99999 ? setWarning(true) : razorPay();
            }}
          >
            <Text style={styles.save}>
              {!selected ? "Proceed" : "Proceed to add" + " £" + selected}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default AddtoWallet;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    marginHorizontal: 20,
  },
  walletBox: {
    borderWidth: 1,
    height: 90,
    borderRadius: 10,
    marginTop: 10,
    borderColor: colors.lightgrey,
    backgroundColor: colors.white,
    elevation: 10,
  },
  innerView: {
    marginHorizontal: 20,
    marginTop: 5,
    flexDirection: "row",
    justifyContent: "space-between",
  },

  innerText: {
    fontFamily: fonts.headerFont,
    fontSize: 16,
    left: 20,
    marginTop: 20,
  },
  innerText2: {
    fontFamily: fonts.headerFont,
    left: 20,
    fontSize: 16,
    width: 150,
    color: colors.darkOrange,
  },
  walletContainer: {
    borderWidth: 1,
    height: 300,
    borderRadius: 10,
    marginTop: 10,
    borderColor: colors.lightgrey,
    backgroundColor: colors.white,
    elevation: 10,
  },
  textInput: {
    borderWidth: 0.5,
    borderColor: "gray",
    borderRadius: 10,
    height: 50,
    justifyContent: "center",
    backgroundColor: "#fff",
    marginHorizontal: 20,
    marginTop: 20,
  },
  warning: {
    color: colors.primary,
    marginHorizontal: 20,
    marginTop: 5,
  },
  buttonsContainer: {
    alignItems: "center",
    width: "95%",
    padding: 8,
    bottom: 10,
  },
  buttonsRowView: {
    flexDirection: "row",
    alignItems: "center",
    // height: "90%",
    width: "95%",
  },
  rippleView: {
    height: "100%",
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    // borderWidth: 1,
    // borderColor: colors.grey,
  },
  buttontitle: {
    fontSize: 16,
    color: colors.grey,
    fontFamily: "Lexend-Medium",
    fontWeight: "700",
    textTransform: "uppercase",
    padding: 5,
    textAlign: "center",
  },
  pressedButtontitle: {
    fontSize: 16,
    color: colors.primary,
    fontFamily: "Lexend-Medium",
    fontWeight: "700",
    textTransform: "uppercase",
    padding: 5,
    textAlign: "center",
  },
  pressedButtonRipple: {
    width: 80,
    height: 35,
    marginVertical: 25,
    borderWidth: 1,
    borderColor: colors.primary,
    marginHorizontal: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonRipple: {
    width: 80,
    height: 35,
    borderWidth: 1,
    borderColor: colors.grey,
    marginVertical: 25,
    marginHorizontal: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  button: {
    backgroundColor: colors.mainButton,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
    bottom: 80,
  },
  save: {
    fontSize: 16,
    fontWeight: "500",
    color: "#FFFFFF",
  },
});
